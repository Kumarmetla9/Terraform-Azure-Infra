# Main configuration file for VM Infrastructure

# Resource Group - Existing only (never created in this stack)
data "azurerm_resource_group" "existing" {
  name = var.resource_group_name
}

# Use existing resource group
locals {
  resource_group_name     = data.azurerm_resource_group.existing.name
  resource_group_location = data.azurerm_resource_group.existing.location
}

# Virtual Network - Existing only (never created in this stack)
locals {
  # Require existing VNet inputs
  vnet_id   = var.vnet_id
  vnet_name = var.vnet_name
}

# Subnet - Existing only (never created in this stack)
locals {
  # Require existing Subnet input (defaults used by consumers unless overridden)
  subnet_id = var.subnet_id
}