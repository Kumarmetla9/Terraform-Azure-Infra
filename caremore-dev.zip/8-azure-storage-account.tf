# =========================================
# Azure Storage Account for Shared Services
# =========================================

# Storage Account with Private Endpoint and RBAC
resource "azurerm_storage_account" "shared" {
  for_each = var.enable_storage_account ? var.storage_accounts : {}

  name                     = each.value.storage_account_name
  resource_group_name      = local.resource_group_name
  location                 = local.resource_group_location
  account_tier             = each.value.account_tier
  account_replication_type = each.value.replication_type
  account_kind             = each.value.account_kind
  min_tls_version          = each.value.min_tls_version

  # Security settings
  public_network_access_enabled   = each.value.public_network_access_enabled
  allow_nested_items_to_be_public = each.value.allow_blob_public_access
  shared_access_key_enabled       = each.value.shared_access_key_enabled

  # Network rules
  network_rules {
    default_action             = each.value.network_default_action
    ip_rules                   = each.value.allowed_ip_ranges
    virtual_network_subnet_ids = each.value.allowed_subnet_ids
    bypass                     = each.value.network_bypass
  }

  # Blob properties
  dynamic "blob_properties" {
    for_each = each.value.enable_versioning || each.value.soft_delete_days > 0 ? [1] : []
    content {
      versioning_enabled = each.value.enable_versioning

      dynamic "container_delete_retention_policy" {
        for_each = each.value.soft_delete_days > 0 ? [1] : []
        content {
          days = each.value.soft_delete_days
        }
      }

      dynamic "delete_retention_policy" {
        for_each = each.value.soft_delete_days > 0 ? [1] : []
        content {
          days = each.value.soft_delete_days
        }
      }
    }
  }

  # Enable hierarchical namespace for Data Lake Gen2
  is_hns_enabled = each.value.enable_data_lake_gen2

  # Managed Identity
  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    var.tags,
    {
      Name    = each.value.storage_account_name
      Service = "shared-storage"
    }
  )

  lifecycle {
    prevent_destroy = false
  }
}

# =========================================
# Storage File Shares (Drives: C, D, T, W, etc.)
# Supports creating shares from snapshots
# =========================================

resource "azurerm_storage_share" "shares" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for share_key, share in storage.file_shares : {
          key           = "${storage_key}-${share_key}"
          storage_key   = storage_key
          storage_name  = storage.storage_account_name
          share_key     = share_key
          share_name    = share.name
          quota_gb      = share.quota_gb
          snapshot_id   = share.snapshot_id
          source_account_id = share.source_storage_account_id
        }
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  name                 = each.value.share_name
  storage_account_name = azurerm_storage_account.shared[each.value.storage_key].name
  quota                = each.value.quota_gb

  # Metadata to track snapshot source (for documentation purposes)
  metadata = each.value.snapshot_id != null ? {
    restored_from_snapshot = each.value.snapshot_id
    restore_timestamp      = timestamp()
  } : {}

  lifecycle {
    ignore_changes = [
      metadata["restore_timestamp"] # Don't recreate on timestamp change
    ]
  }
}

# =========================================
# Null Resource to Restore Data from Snapshot
# Note: Terraform doesn't natively support restoring from snapshots
# This uses Azure CLI to copy data from snapshot after share creation
# =========================================

resource "null_resource" "restore_from_snapshot" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for share_key, share in storage.file_shares : {
          key           = "${storage_key}-${share_key}"
          storage_key   = storage_key
          share_name    = share.name
          snapshot_id   = share.snapshot_id
        }
      ]
    ]) : item.key => item
    if var.enable_storage_account && item.snapshot_id != null
  }

  # Trigger re-run if snapshot ID changes
  triggers = {
    snapshot_id = each.value.snapshot_id
    share_id    = azurerm_storage_share.shares[each.key].id
  }

  # Note: This requires Azure CLI and appropriate authentication
  # The snapshot_id format: https://<account>.file.core.windows.net/<share>?snapshot=<timestamp>
  provisioner "local-exec" {
    command = <<-EOT
      Write-Host "File share '${each.value.share_name}' created."
      Write-Host "To restore from snapshot, run the following Azure CLI command:"
      Write-Host "az storage file copy start-batch --source-account-name <source-account> --source-share <source-share> --source-snapshot <snapshot-timestamp> --destination-account-name ${azurerm_storage_account.shared[each.value.storage_key].name} --destination-share ${each.value.share_name} --account-key <storage-account-key>"
      Write-Host "Snapshot ID: ${each.value.snapshot_id}"
    EOT
    interpreter = ["PowerShell", "-Command"]
  }

  depends_on = [azurerm_storage_share.shares]
}

# =========================================
# Per-File-Share RBAC Assignments
# =========================================

# Storage File Data SMB Share Reader - Per Share
resource "azurerm_role_assignment" "file_share_reader" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for share_key, share in storage.file_shares : [
          for principal_key, principal_id in share.rbac_readers : {
            key          = "${storage_key}-${share_key}-reader-${principal_key}"
            storage_key  = storage_key
            share_key    = share_key
            share_name   = share.name
            principal_id = principal_id
          }
        ]
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = "${azurerm_storage_account.shared[each.value.storage_key].id}/fileServices/default/fileshares/${azurerm_storage_share.shares["${each.value.storage_key}-${each.value.share_key}"].name}"
  role_definition_name = "Storage File Data SMB Share Reader"
  principal_id         = each.value.principal_id

  depends_on = [azurerm_storage_share.shares]
}

# Storage File Data SMB Share Contributor - Per Share
resource "azurerm_role_assignment" "file_share_contributor" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for share_key, share in storage.file_shares : [
          for principal_key, principal_id in share.rbac_contributors : {
            key          = "${storage_key}-${share_key}-contributor-${principal_key}"
            storage_key  = storage_key
            share_key    = share_key
            share_name   = share.name
            principal_id = principal_id
          }
        ]
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = "${azurerm_storage_account.shared[each.value.storage_key].id}/fileServices/default/fileshares/${azurerm_storage_share.shares["${each.value.storage_key}-${each.value.share_key}"].name}"
  role_definition_name = "Storage File Data SMB Share Contributor"
  principal_id         = each.value.principal_id

  depends_on = [azurerm_storage_share.shares]
}

# Storage File Data SMB Share Elevated Contributor - Per Share
resource "azurerm_role_assignment" "file_share_elevated_contributor" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for share_key, share in storage.file_shares : [
          for principal_key, principal_id in share.rbac_elevated_contributors : {
            key          = "${storage_key}-${share_key}-elevated-${principal_key}"
            storage_key  = storage_key
            share_key    = share_key
            share_name   = share.name
            principal_id = principal_id
          }
        ]
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = "${azurerm_storage_account.shared[each.value.storage_key].id}/fileServices/default/fileshares/${azurerm_storage_share.shares["${each.value.storage_key}-${each.value.share_key}"].name}"
  role_definition_name = "Storage File Data SMB Share Elevated Contributor"
  principal_id         = each.value.principal_id

  depends_on = [azurerm_storage_share.shares]
}

# =========================================
# Private Endpoints for Storage
# =========================================

# Private Endpoint for Blob
resource "azurerm_private_endpoint" "storage_blob" {
  for_each = {
    for k, v in var.storage_accounts : k => v
    if var.enable_storage_account && v.private_endpoint_enabled && v.pe_enable_blob
  }

  name                = "pe-${each.value.storage_account_name}-blob"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id != null ? each.value.private_endpoint_subnet_id : local.subnet_id

  private_service_connection {
    name                           = "psc-${each.value.storage_account_name}-blob"
    private_connection_resource_id = azurerm_storage_account.shared[each.key].id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }

  tags = var.tags
}

# Private Endpoint for File
resource "azurerm_private_endpoint" "storage_file" {
  for_each = {
    for k, v in var.storage_accounts : k => v
    if var.enable_storage_account && v.private_endpoint_enabled && v.pe_enable_file
  }

  name                = "pe-${each.value.storage_account_name}-file"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id != null ? each.value.private_endpoint_subnet_id : local.subnet_id

  private_service_connection {
    name                           = "psc-${each.value.storage_account_name}-file"
    private_connection_resource_id = azurerm_storage_account.shared[each.key].id
    subresource_names              = ["file"]
    is_manual_connection           = false
  }

  tags = var.tags
}

# =========================================
# RBAC Assignments - Storage Blob Data Reader
# =========================================

resource "azurerm_role_assignment" "storage_blob_reader" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for principal_key, principal_id in storage.rbac_blob_readers : {
          key          = "${storage_key}-reader-${principal_key}"
          storage_key  = storage_key
          principal_id = principal_id
          scope        = azurerm_storage_account.shared[storage_key].id
        }
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = each.value.scope
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = each.value.principal_id
}

# =========================================
# RBAC Assignments - Storage Blob Data Contributor
# =========================================

resource "azurerm_role_assignment" "storage_blob_contributor" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for principal_key, principal_id in storage.rbac_blob_contributors : {
          key          = "${storage_key}-contributor-${principal_key}"
          storage_key  = storage_key
          principal_id = principal_id
          scope        = azurerm_storage_account.shared[storage_key].id
        }
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = each.value.scope
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = each.value.principal_id
}

# =========================================
# RBAC Assignments - Storage File Data SMB Share Reader
# =========================================

resource "azurerm_role_assignment" "storage_file_reader" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for principal_key, principal_id in storage.rbac_file_readers : {
          key          = "${storage_key}-file-reader-${principal_key}"
          storage_key  = storage_key
          principal_id = principal_id
          scope        = azurerm_storage_account.shared[storage_key].id
        }
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = each.value.scope
  role_definition_name = "Storage File Data SMB Share Reader"
  principal_id         = each.value.principal_id
}

# =========================================
# RBAC Assignments - Storage File Data SMB Share Contributor
# =========================================

resource "azurerm_role_assignment" "storage_file_contributor" {
  for_each = {
    for item in flatten([
      for storage_key, storage in var.storage_accounts : [
        for principal_key, principal_id in storage.rbac_file_contributors : {
          key          = "${storage_key}-file-contributor-${principal_key}"
          storage_key  = storage_key
          principal_id = principal_id
          scope        = azurerm_storage_account.shared[storage_key].id
        }
      ]
    ]) : item.key => item
    if var.enable_storage_account
  }

  scope                = each.value.scope
  role_definition_name = "Storage File Data SMB Share Contributor"
  principal_id         = each.value.principal_id
}

# =========================================
# Management Lock
# =========================================

resource "azurerm_management_lock" "storage" {
  for_each = {
    for k, v in var.storage_accounts : k => v
    if var.enable_storage_account && v.enable_resource_lock
  }

  name       = "lock-${each.value.storage_account_name}"
  scope      = azurerm_storage_account.shared[each.key].id
  lock_level = "CanNotDelete"
  notes      = "Prevents accidental deletion of shared platform storage"
}
