## Remote state to read outputs from terraform-network-code
## This enables infra to consume VNet/Subnet/NSG IDs and names.

// Intentionally left blank: remote state removed.
// This stack must receive existing network IDs via variables.
