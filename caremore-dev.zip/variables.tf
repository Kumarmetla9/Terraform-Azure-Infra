# Common Variables
variable "resource_group_name" {
  description = "Name of the existing resource group (this stack will NOT create it)"
  type        = string
  default     = null
  validation {
    condition     = var.resource_group_name != null && length(var.resource_group_name) > 0
    error_message = "resource_group_name is required and must reference an existing Resource Group."
  }
}

variable "location" {
  description = "Azure region where resources will be created (informational; actual RG location is read from the existing RG)"
  type        = string
  default     = "East US"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "tags" {
  description = "Common tags for all resources"
  type        = map(string)
  default = {
    Environment = "dev"
    Project     = "VM-Infrastructure"
    Owner       = "DevOps-Team"
  }
}

# Network Variables
variable "vnet_name" {
  description = "Name of the virtual network"
  type        = string
  default     = "vnet-vm-infrastructure"
}

variable "vnet_id" {
  description = "ID of the existing virtual network (when using existing network)"
  type        = string
  default     = null
  validation {
    condition     = var.vnet_id != null && length(var.vnet_id) > 0
    error_message = "vnet_id is required. This stack does not create VNets; provide an existing VNet ID."
  }
}

variable "vnet_address_space" {
  description = "Address space for the virtual network"
  type        = list(string)
  default     = ["10.0.0.0/16"]
}

variable "subnet_name" {
  description = "Name of the subnet"
  type        = string
  default     = "subnet-vms"
}

variable "subnet_id" {
  description = "ID of the existing subnet (when using existing network)"
  type        = string
  default     = null
}

variable "subnet_address_prefixes" {
  description = "Address prefix for the subnet"
  type        = list(string)
  default     = ["10.0.1.0/24"]
}

variable "existing_nsg_id" {
  description = "ID of the existing NSG to use (when using existing network)"
  type        = string
  default     = null
}

variable "existing_nsg_name" {
  description = "Name of the existing NSG to use (when using existing network)"
  type        = string
  default     = null
}

variable "use_existing_network" {
  description = "Whether to use existing network resources instead of creating new ones"
  type        = bool
  default     = false
}

# Tier-based Network Mapping
variable "tier_subnet_mapping" {
  description = "Mapping of tiers to subnet IDs"
  type        = map(string)
  default     = {}
  # Example:
  # {
  #   "web" = "/subscriptions/.../subnets/SUBNET-WEB-caremore-dev"
  #   "app" = "/subscriptions/.../subnets/SUBNET-APP-caremore-dev"
  #   "database" = "/subscriptions/.../subnets/SUBNET-DB-caremore-dev"
  # }
}

variable "tier_nsg_mapping" {
  description = "Mapping of tiers to NSG IDs"
  type        = map(string)
  default     = {}
  # Example:
  # {
  #   "web" = "/subscriptions/.../networkSecurityGroups/NSG-WEB-caremore-dev"
  #   "app" = "/subscriptions/.../networkSecurityGroups/NSG-APP-caremore-dev"
  #   "database" = "/subscriptions/.../networkSecurityGroups/NSG-DB-caremore-dev"
  # }
}

# Multiple Windows VMs Configuration
variable "windows_vms" {
  description = "Map of Windows VMs to create with their configurations"
  type = map(object({
    vm_size                        = string
    admin_username                 = string
    admin_password                 = string
    os_disk_storage_account_type   = optional(string, "Premium_LRS")
    os_disk_caching                = optional(string, "ReadWrite")
    image_sku                      = optional(string, "2022-Datacenter")
    image_publisher                = optional(string, "MicrosoftWindowsServer")
    image_offer                    = optional(string, "WindowsServer")
    image_version                  = optional(string, "latest")
    create_data_disk               = optional(bool, false)
    data_disk_size_gb              = optional(number, 64)
    data_disk_storage_account_type = optional(string, "Standard_LRS")
    # Network configuration per VM
    subnet_id          = optional(string, null)      # Override subnet for this VM
    nsg_id             = optional(string, null)      # Override NSG for this VM
    tier               = optional(string, "private") # Tier type: public, private, bastion (legacy: web/app/database -> map to public/private)
    private_ip_address = optional(string, null)      # Static private IP (leave null for auto-assignment on first create)
  }))
  default = {}
}

# Legacy single Windows VM Variables (for backward compatibility)
variable "windows_vm_name" {
  description = "Name of the Windows VM (legacy - use windows_vms for multiple VMs)"
  type        = string
  default     = "vm-windows"
}

variable "windows_vm_size" {
  description = "Size of the Windows VM (legacy - use windows_vms for multiple VMs)"
  type        = string
  default     = "Standard_B2s"
}

variable "windows_admin_username" {
  description = "Administrator username for Windows VM (legacy - use windows_vms for multiple VMs)"
  type        = string
  default     = "azureadmin"
}

variable "windows_admin_password" {
  description = "Administrator password for Windows VM (legacy - use windows_vms for multiple VMs)"
  type        = string
  sensitive   = true
  default     = null
}

variable "windows_os_disk_caching" {
  description = "Caching type for Windows VM OS disk"
  type        = string
  default     = "ReadWrite"
}

variable "windows_os_disk_storage_account_type" {
  description = "Storage account type for Windows VM OS disk"
  type        = string
  default     = "Premium_LRS"
}

variable "windows_image_publisher" {
  description = "Publisher of the Windows VM image"
  type        = string
  default     = "MicrosoftWindowsServer"
}

variable "windows_image_offer" {
  description = "Offer of the Windows VM image"
  type        = string
  default     = "WindowsServer"
}

variable "windows_image_sku" {
  description = "SKU of the Windows VM image"
  type        = string
  default     = "2022-Datacenter"
}

variable "windows_image_version" {
  description = "Version of the Windows VM image"
  type        = string
  default     = "latest"
}

# Multiple Linux VMs Configuration
variable "linux_vms" {
  description = "Map of Linux VMs to create with their configurations"
  type = map(object({
    vm_size                         = string
    admin_username                  = string
    admin_password                  = optional(string, null)
    disable_password_authentication = optional(bool, false)
    ssh_public_key                  = optional(string, null)
    os_disk_storage_account_type    = optional(string, "Premium_LRS")
    os_disk_caching                 = optional(string, "ReadWrite")
    image_sku                       = optional(string, "20_04-lts-gen2")
    image_publisher                 = optional(string, "Canonical")
    image_offer                     = optional(string, "0001-com-ubuntu-server-focal")
    image_version                   = optional(string, "latest")
    create_data_disk                = optional(bool, false)
    data_disk_size_gb               = optional(number, 64)
    data_disk_storage_account_type  = optional(string, "Standard_LRS")
    # Network configuration per VM
    subnet_id          = optional(string, null)      # Override subnet for this VM
    nsg_id             = optional(string, null)      # Override NSG for this VM
    tier               = optional(string, "private") # Tier type: public, private, bastion (legacy: web/app/database -> map to public/private)
    private_ip_address = optional(string, null)      # Static private IP (leave null for auto-assignment on first create)
  }))
  default = {}
}

# Legacy single Linux VM Variables (for backward compatibility)
variable "linux_vm_name" {
  description = "Name of the Linux VM (legacy - use linux_vms for multiple VMs)"
  type        = string
  default     = "vm-linux"
}

variable "linux_vm_size" {
  description = "Size of the Linux VM (legacy - use linux_vms for multiple VMs)"
  type        = string
  default     = "Standard_B2s"
}

variable "linux_admin_username" {
  description = "Administrator username for Linux VM (legacy - use linux_vms for multiple VMs)"
  type        = string
  default     = "azureadmin"
}

variable "linux_admin_password" {
  description = "Administrator password for Linux VM (optional if using SSH keys) (legacy - use linux_vms for multiple VMs)"
  type        = string
  sensitive   = true
  default     = null
}

variable "disable_password_authentication" {
  description = "Disable password authentication for Linux VM (legacy - use linux_vms for multiple VMs)"
  type        = bool
  default     = false
}

variable "linux_ssh_public_key" {
  description = "SSH public key for Linux VM authentication (legacy - use linux_vms for multiple VMs)"
  type        = string
  default     = null
}

variable "linux_os_disk_caching" {
  description = "Caching type for Linux VM OS disk"
  type        = string
  default     = "ReadWrite"
}

variable "linux_os_disk_storage_account_type" {
  description = "Storage account type for Linux VM OS disk"
  type        = string
  default     = "Premium_LRS"
}

variable "linux_image_publisher" {
  description = "Publisher of the Linux VM image"
  type        = string
  default     = "Canonical"
}

variable "linux_image_offer" {
  description = "Offer of the Linux VM image"
  type        = string
  default     = "0001-com-ubuntu-server-focal"
}

variable "linux_image_sku" {
  description = "SKU of the Linux VM image"
  type        = string
  default     = "20_04-lts-gen2"
}

variable "linux_image_version" {
  description = "Version of the Linux VM image"
  type        = string
  default     = "latest"
}

# Security Variables
variable "allow_rdp_from_internet" {
  description = "Allow RDP access from internet to Windows VM"
  type        = bool
  default     = false
}

variable "allow_ssh_from_internet" {
  description = "Allow SSH access from internet to Linux VM"
  type        = bool
  default     = false
}

variable "allowed_ip_ranges" {
  description = "List of IP ranges allowed to access VMs"
  type        = list(string)
  default     = []
}

# Storage Variables
variable "create_data_disks" {
  description = "Whether to create additional data disks for VMs"
  type        = bool
  default     = false
}

variable "data_disk_size_gb" {
  description = "Size of additional data disks in GB"
  type        = number
  default     = 64
}

variable "data_disk_storage_account_type" {
  description = "Storage account type for data disks"
  type        = string
  default     = "Standard_LRS"
}

# Azure Bastion Variables
variable "enable_bastion" {
  description = "Enable Azure Bastion for secure VM access"
  type        = bool
  default     = false
}

variable "bastion_name" {
  description = "Name of the Azure Bastion host"
  type        = string
  default     = "bastion-host"
}

variable "bastion_sku" {
  description = "SKU of Azure Bastion (Basic or Standard)"
  type        = string
  default     = "Basic"
  validation {
    condition     = contains(["Basic", "Standard"], var.bastion_sku)
    error_message = "Bastion SKU must be either 'Basic' or 'Standard'."
  }
}

variable "bastion_subnet_address_prefixes" {
  description = "Address prefixes for the AzureBastionSubnet (minimum /26)"
  type        = list(string)
  default     = ["10.0.2.0/26"]
}

variable "bastion_subnet_id" {
  description = "Existing subnet ID to use for Bastion host (alternative to creating dedicated AzureBastionSubnet)"
  type        = string
  default     = null
}

# Bastion NSG Configuration
variable "bastion_nsg_id" {
  description = "ID of the NSG to use for the Bastion subnet"
  type        = string
  default     = null
}

variable "bastion_nsg_name" {
  description = "Name of the NSG to use for the Bastion subnet"
  type        = string
  default     = null
}

# Bastion Standard SKU Features
variable "bastion_copy_paste_enabled" {
  description = "Enable copy/paste functionality (Standard SKU only)"
  type        = bool
  default     = true
}

variable "bastion_file_copy_enabled" {
  description = "Enable file copy functionality (Standard SKU only)"
  type        = bool
  default     = true
}

variable "bastion_ip_connect_enabled" {
  description = "Enable IP connect functionality - connect via private IP (Standard SKU only)"
  type        = bool
  default     = true
}

variable "bastion_shareable_link_enabled" {
  description = "Enable shareable link functionality (Standard SKU only)"
  type        = bool
  default     = false
}

variable "bastion_tunneling_enabled" {
  description = "Enable tunneling functionality for native client support (Standard SKU only)"
  type        = bool
  default     = true
}

# Bastion Diagnostics
variable "enable_bastion_diagnostics" {
  description = "Enable diagnostic settings for Azure Bastion (deprecated: prefer enable_diagnostics)"
  type        = bool
  default     = false
}

variable "log_analytics_workspace_id" {
  description = "Log Analytics workspace ID for diagnostic settings (Bastion, SQL, Synapse, Storage)"
  type        = string
  default     = null
}

# Global Diagnostics Toggle
variable "enable_diagnostics" {
  description = "Enable Azure Monitor diagnostic settings for supported resources in this stack"
  type        = bool
  default     = false
}

# Virtual Machine Diagnostics via Azure Monitor Agent (AMA)
variable "enable_vm_diagnostics" {
  description = "Install Azure Monitor Agent on VMs and associate a Data Collection Rule to send logs/metrics to Log Analytics"
  type        = bool
  default     = false
}

variable "syslog_facilities" {
  description = "Syslog facilities to collect on Linux VMs"
  type        = list(string)
  default     = ["auth", "authpriv", "daemon", "kern", "syslog", "user"]
}

variable "syslog_levels" {
  description = "Syslog levels to collect on Linux VMs"
  type        = list(string)
  default     = ["Debug", "Info", "Notice", "Warning", "Error", "Critical", "Alert", "Emergency"]
}

variable "vm_perf_counters" {
  description = "Windows Performance Counter specifiers to collect (applies to Windows VMs). Linux VMs ignore unsupported counters."
  type        = list(string)
  default = [
    "\\Processor(_Total)\\% Processor Time",
    "\\Memory\\% Committed Bytes In Use",
    "\\LogicalDisk(_Total)\\% Free Space"
  ]
}

# Diagnostic categories per resource (logs)


variable "synapse_workspace_diag_log_categories" {
  description = "Log categories to enable for Synapse Workspace diagnostic settings. Leave empty to skip logs."
  type        = list(string)
  default     = []
}

variable "synapse_sql_pool_diag_log_categories" {
  description = "Log categories to enable for Synapse SQL Pool diagnostic settings. Leave empty to skip logs."
  type        = list(string)
  default     = []
}

variable "storage_account_diag_log_categories" {
  description = "Log categories to enable for Synapse-linked Storage Account diagnostic settings (e.g., StorageRead, StorageWrite, StorageDelete). Leave empty to skip logs."
  type        = list(string)
  default     = []
}

# Azure AD Groups Configuration - References existing groups
# These groups should be created by terraform-ad-groups module first
variable "enable_ad_groups" {
  description = "Enable Azure AD group access control for infrastructure resources (references existing groups)"
  type        = bool
  default     = false
}

variable "admin_group_name" {
  description = "Name of the existing Azure AD admin group (created by terraform-ad-groups module)"
  type        = string
  default     = null
}

variable "readonly_group_name" {
  description = "Name of the existing Azure AD readonly group (created by terraform-ad-groups module)"
  type        = string
  default     = null
}

variable "target_resource_id" {
  description = "Resource ID to assign Azure AD group permissions to (e.g., specific host, resource group). If null, defaults to resource group."
  type        = string
  default     = null
}

variable "use_infrastructure_resource_as_target" {
  description = "Use a specific infrastructure resource as target (e.g., 'bastion_host'). If null, uses resource group."
  type        = string
  default     = null
}

variable "admin_group_role" {
  description = "Role to assign to the admin group"
  type        = string
  default     = "Contributor"
}

variable "readonly_group_role" {
  description = "Role to assign to the readonly group"
  type        = string
  default     = "Reader"
}

# =========================================
# Azure Synapse SQL Pool Variables
# =========================================

variable "enable_synapse_sql_pool" {
  description = "Enable Azure Synapse SQL Pool (Dedicated SQL Pool / Data Warehouse)"
  type        = bool
  default     = false
}

variable "synapse_instances" {
  description = "Map of Synapse instances to create with their configurations"
  type = map(object({
    workspace_name           = string
    storage_account_name     = string
    filesystem_name          = string
    sql_pool_name            = string
    sql_admin_username       = string
    sql_admin_password       = string
    storage_account_tier     = string
    storage_replication_type = string
    managed_vnet_enabled     = bool
    sql_pool_sku             = string
    sql_pool_collation       = string
    aad_admin_login          = string
    aad_admin_object_id      = string
    aad_admin_tenant_id      = string
    firewall_rules = map(object({
      start_ip = string
      end_ip   = string
    }))
    private_endpoint_enabled      = bool
    private_endpoint_subnet_id    = string
    pe_enable_dev                 = bool
    pe_enable_sql_ondemand        = bool
    public_network_access_enabled = bool
  }))
  default = {}
}

variable "synapse_storage_account_tier" {
  description = "Storage account tier for Synapse (Standard or Premium)"
  type        = string
  default     = "Standard"
}

variable "synapse_storage_replication_type" {
  description = "Storage replication type (LRS, GRS, RAGRS, ZRS)"
  type        = string
  default     = "LRS"
}

variable "synapse_filesystem_name" {
  description = "Name of the Data Lake Gen2 filesystem for Synapse"
  type        = string
  default     = "synapse-filesystem"
}

variable "synapse_sql_admin_username" {
  description = "SQL Administrator username for Synapse Workspace"
  type        = string
  default     = "sqladmin"
}

variable "synapse_sql_admin_password" {
  description = "SQL Administrator password for Synapse Workspace"
  type        = string
  sensitive   = true
  default     = null
}

variable "synapse_managed_vnet_enabled" {
  description = "Enable managed virtual network for Synapse Workspace"
  type        = bool
  default     = false
}

variable "synapse_sql_pool_name" {
  description = "Name of the Synapse SQL Pool (Dedicated SQL Pool)"
  type        = string
  default     = "sqlpool"
}

variable "synapse_sql_pool_sku" {
  description = "SKU for SQL Pool (DW100c, DW200c, DW300c, DW400c, DW500c, DW1000c, DW1500c, DW2000c, DW2500c, DW3000c, etc.)"
  type        = string
  default     = "DW100c"
}

variable "synapse_sql_pool_collation" {
  description = "Collation for the SQL Pool"
  type        = string
  default     = "SQL_Latin1_General_CP1_CI_AS"
}

# Azure AD Admin Configuration for Synapse
variable "synapse_aad_admin_login" {
  description = "Azure AD admin login name for Synapse"
  type        = string
  default     = null
}

variable "synapse_aad_admin_object_id" {
  description = "Azure AD admin object ID for Synapse"
  type        = string
  default     = null
}

variable "synapse_aad_admin_tenant_id" {
  description = "Azure AD admin tenant ID for Synapse"
  type        = string
  default     = null
}

# Synapse Firewall Configuration
variable "synapse_firewall_rules" {
  description = "Map of firewall rules for Synapse Workspace"
  type = map(object({
    start_ip = string
    end_ip   = string
  }))
  default = {}
}

# Synapse Private Endpoint Configuration
variable "enable_synapse_private_endpoint" {
  description = "Enable private endpoint for Synapse Workspace"
  type        = bool
  default     = false
}

variable "synapse_private_endpoint_subnet_id" {
  description = "Subnet ID for Synapse private endpoint (if null, uses default subnet)"
  type        = string
  default     = null
}

variable "synapse_public_network_access_enabled" {
  description = "Allow public network access to Synapse Workspace (set false to force private-only via Private Endpoints)"
  type        = bool
  default     = false
}

# Synapse Private Endpoint subresources toggles
variable "synapse_pe_enable_sql" {
  description = "Create Synapse Private Endpoint for Dedicated SQL endpoint (subresource: Sql)"
  type        = bool
  default     = true
}

variable "synapse_pe_enable_sql_ondemand" {
  description = "Create Synapse Private Endpoint for Serverless SQL endpoint (subresource: SqlOnDemand)"
  type        = bool
  default     = false
}

variable "synapse_pe_enable_dev" {
  description = "Create Synapse Private Endpoint for Workspace Dev/Web (subresource: Dev)"
  type        = bool
  default     = false
}


# Synapse user-defined restore points (on-demand via CLI)
variable "synapse_create_restore_point" {
  description = "Create a user-defined restore point for the Synapse Dedicated SQL Pool during apply (uses Azure CLI)."
  type        = bool
  default     = false
}

variable "synapse_restore_point_label" {
  description = "Label for the Synapse restore point (required if synapse_create_restore_point = true)."
  type        = string
  default     = null
}

# =========================================
# Azure SQL Serverless Variables
# =========================================

variable "enable_sql_serverless" {
  description = "Enable Azure SQL Serverless instances"
  type        = bool
  default     = false
}

variable "sql_serverless_instances" {
  description = "Map of SQL Serverless instances to create with their configurations"
  type = map(object({
    server_name              = string
    database_name            = string
    sql_admin_username       = string
    sql_admin_password       = string
    server_version           = string
    minimum_capacity         = number
    max_size_bytes           = number
    auto_pause_delay_minutes = number
    aad_admin_login          = string
    aad_admin_object_id      = string
    aad_admin_tenant_id      = string
    firewall_rules = map(object({
      start_ip = string
      end_ip   = string
    }))
    private_endpoint_enabled      = bool
    private_endpoint_subnet_id    = string
    public_network_access_enabled = bool
    enable_high_availability      = bool
    zone_redundant                = bool
    geo_backup_enabled            = bool
    backup_retention_days         = number
    diagnostic_settings_enabled   = bool
  }))
  default = {}
}

variable "sql_serverless_version" {
  description = "Version for SQL Server (default 12.0)"
  type        = string
  default     = "12.0"
}

variable "sql_serverless_minimum_capacity" {
  description = "Minimum capacity in vCores (0.5 to 16)"
  type        = number
  default     = 0.5
}

variable "sql_serverless_max_size_bytes" {
  description = "Maximum size of the database in bytes"
  type        = number
  default     = 34359738368 # 32GB
}

variable "sql_serverless_auto_pause_delay" {
  description = "Time in minutes after which database is automatically paused. -1 to disable"
  type        = number
  default     = 60
}

variable "sql_serverless_firewall_rules" {
  description = "Map of firewall rules for SQL Server"
  type = map(object({
    start_ip = string
    end_ip   = string
  }))
  default = {}
}

variable "sql_serverless_private_endpoint_subnet_id" {
  description = "Subnet ID for SQL Server private endpoint"
  type        = string
  default     = null
}

variable "sql_serverless_backup_retention_days" {
  description = "Backup retention days for SQL Server (7-35 days)"
  type        = number
  default     = 7
  validation {
    condition     = var.sql_serverless_backup_retention_days >= 7 && var.sql_serverless_backup_retention_days <= 35
    error_message = "Backup retention days must be between 7 and 35 days."
  }
}

variable "sql_serverless_geo_backup_enabled" {
  description = "Enable geo-backup for SQL Server"
  type        = bool
  default     = true
}

variable "sql_serverless_zone_redundant" {
  description = "Enable zone redundancy for SQL Server"
  type        = bool
  default     = false
}

variable "sql_serverless_enable_high_availability" {
  description = "Enable high availability for SQL Server"
  type        = bool
  default     = false
}

variable "sql_serverless_public_network_access" {
  description = "Enable public network access for SQL Server"
  type        = bool
  default     = false
}

variable "sql_serverless_diagnostic_settings_enabled" {
  description = "Enable diagnostic settings for SQL Server"
  type        = bool
  default     = false
}

variable "sql_serverless_aad_admin_login" {
  description = "Azure AD admin login name for SQL Server"
  type        = string
  default     = null
}

variable "sql_serverless_aad_admin_object_id" {
  description = "Azure AD admin object ID for SQL Server"
  type        = string
  default     = null
}

variable "sql_serverless_aad_admin_tenant_id" {
  description = "Azure AD admin tenant ID for SQL Server"
  type        = string
  default     = null
}

# =========================================
# Azure SQL Server with Elastic Pool Variables
# =========================================

variable "enable_sql_elastic_pool" {
  description = "Enable Azure SQL Server with Elastic Pool"
  type        = bool
  default     = false
}

variable "sql_elastic_instances" {
  description = "Map of SQL Server instances with Elastic Pool configurations"
  type = map(object({
    server_name              = string
    sql_admin_username       = string
    sql_admin_password       = string
    server_version           = string
    elastic_pool_name        = string
    elastic_pool_max_size_gb = number
    elastic_pool_sku = object({
      name     = string
      tier     = string
      capacity = number
    })
    databases = map(object({
      name                  = string
      collation             = string
      max_size_gb           = number
      min_capacity          = number
      max_capacity          = number
      zone_redundant        = bool
      backup_retention_days = number
    }))
    aad_admin_login     = string
    aad_admin_object_id = string
    aad_admin_tenant_id = string
    firewall_rules = map(object({
      start_ip = string
      end_ip   = string
    }))
    private_endpoint_enabled      = bool
    private_endpoint_subnet_id    = string
    public_network_access_enabled = bool
    enable_high_availability      = bool
    zone_redundant                = bool
    geo_backup_enabled            = bool
    diagnostic_settings_enabled   = bool
  }))
  default = {}
}

variable "sql_elastic_version" {
  description = "Version for SQL Server (default 12.0)"
  type        = string
  default     = "12.0"
}

variable "sql_elastic_backup_retention_days" {
  description = "Backup retention days for SQL Server databases (7-35 days)"
  type        = number
  default     = 7
  validation {
    condition     = var.sql_elastic_backup_retention_days >= 7 && var.sql_elastic_backup_retention_days <= 35
    error_message = "Backup retention days must be between 7 and 35 days."
  }
}

variable "sql_elastic_geo_backup_enabled" {
  description = "Enable geo-backup for SQL Server databases"
  type        = bool
  default     = true
}

variable "sql_elastic_zone_redundant" {
  description = "Enable zone redundancy for SQL Server"
  type        = bool
  default     = false
}

variable "sql_elastic_enable_high_availability" {
  description = "Enable high availability for SQL Server"
  type        = bool
  default     = false
}

variable "sql_elastic_public_network_access" {
  description = "Enable public network access for SQL Server"
  type        = bool
  default     = false
}

variable "sql_elastic_diagnostic_settings_enabled" {
  description = "Enable diagnostic settings for SQL Server"
  type        = bool
  default     = true
}

variable "sql_elastic_aad_admin_login" {
  description = "Azure AD admin login name for SQL Server"
  type        = string
  default     = null
}

variable "sql_elastic_aad_admin_object_id" {
  description = "Azure AD admin object ID for SQL Server"
  type        = string
  default     = null
}

variable "sql_elastic_aad_admin_tenant_id" {
  description = "Azure AD admin tenant ID for SQL Server"
  type        = string
  default     = null
}

# =========================================
# Azure Storage Account Variables
# =========================================

variable "enable_storage_account" {
  description = "Enable Azure Storage Account for shared services"
  type        = bool
  default     = false
}

variable "storage_accounts" {
  description = "Map of Storage Accounts to create with their configurations"
  type = map(object({
    storage_account_name          = string
    account_tier                  = string
    replication_type              = string
    account_kind                  = string
    min_tls_version               = string
    public_network_access_enabled = bool
    allow_blob_public_access      = bool
    shared_access_key_enabled     = bool
    enable_versioning             = bool
    soft_delete_days              = number
    enable_data_lake_gen2         = bool

    # Network settings
    network_default_action = string
    allowed_ip_ranges      = list(string)
    allowed_subnet_ids     = list(string)
    network_bypass         = list(string)

    # Private endpoint settings
    private_endpoint_enabled   = bool
    private_endpoint_subnet_id = string
    pe_enable_blob             = bool
    pe_enable_file             = bool
    pe_enable_queue            = bool

    # File shares (drives like C, D, T, W)
    file_shares = map(object({
      name                       = string
      quota_gb                   = number
      rbac_readers               = optional(map(string), {}) # Map of name => principal_id for read-only access
      rbac_contributors          = optional(map(string), {}) # Map of name => principal_id for read-write access
      rbac_elevated_contributors = optional(map(string), {}) # Map of name => principal_id for full control access
      snapshot_id                = optional(string, null)    # Snapshot URL to restore from (format: https://<account>.file.core.windows.net/<share>?snapshot=<timestamp>)
      source_storage_account_id  = optional(string, null)    # Source storage account resource ID for cross-account snapshot restore
    }))

    # RBAC - Principal IDs (Managed Identity, User, Group, Service Principal)
    rbac_blob_readers      = map(string) # Map of name => principal_id for Storage Blob Data Reader
    rbac_blob_contributors = map(string) # Map of name => principal_id for Storage Blob Data Contributor
    rbac_file_readers      = map(string) # Map of name => principal_id for Storage File Data SMB Share Reader
    rbac_file_contributors = map(string) # Map of name => principal_id for Storage File Data SMB Share Contributor

    # Resource lock
    enable_resource_lock = bool
  }))
  default = {}
}




