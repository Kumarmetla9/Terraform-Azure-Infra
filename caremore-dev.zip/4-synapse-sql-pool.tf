# Azure Synapse Analytics Workspace and SQL Pool Configuration
locals {
  synapse_instances_with_pe = {
    for k, v in var.synapse_instances : k => v
    if var.enable_synapse_sql_pool && v.private_endpoint_enabled
  }
}

# Storage Account for Synapse Data Lake (required for Synapse Workspace)
resource "azurerm_storage_account" "synapse" {
  for_each                 = var.enable_synapse_sql_pool ? var.synapse_instances : {}
  name                     = each.value.storage_account_name
  resource_group_name      = local.resource_group_name
  location                 = local.resource_group_location
  account_tier             = each.value.storage_account_tier
  account_replication_type = each.value.storage_replication_type
  account_kind             = "StorageV2"
  is_hns_enabled           = true # Hierarchical namespace required for Data Lake Gen2

  tags = var.tags
}

# Storage Data Lake Gen2 Filesystem for Synapse
resource "azurerm_storage_data_lake_gen2_filesystem" "synapse" {
  for_each           = var.enable_synapse_sql_pool ? var.synapse_instances : {}
  name               = each.value.filesystem_name
  storage_account_id = azurerm_storage_account.synapse[each.key].id

  depends_on = [azurerm_storage_account.synapse]
}

# Azure Synapse Workspace
resource "azurerm_synapse_workspace" "main" {
  for_each                             = var.enable_synapse_sql_pool ? var.synapse_instances : {}
  name                                 = each.value.workspace_name
  resource_group_name                  = local.resource_group_name
  location                             = local.resource_group_location
  storage_data_lake_gen2_filesystem_id = azurerm_storage_data_lake_gen2_filesystem.synapse[each.key].id
  sql_administrator_login              = each.value.sql_admin_username
  sql_administrator_login_password     = each.value.sql_admin_password
  managed_virtual_network_enabled      = each.value.managed_vnet_enabled
  public_network_access_enabled        = each.value.public_network_access_enabled

  # Azure AD Authentication (optional)
  dynamic "aad_admin" {
    for_each = each.value.aad_admin_login != null ? [1] : []
    content {
      login     = each.value.aad_admin_login
      object_id = each.value.aad_admin_object_id
      tenant_id = each.value.aad_admin_tenant_id
    }
  }

  identity {
    type = "SystemAssigned"
  }

  tags = var.tags
}

# Custom firewall rules for specific IP ranges
resource "azurerm_synapse_firewall_rule" "custom" {
  for_each = {
    for pair in flatten([
      for ws_key, ws in var.synapse_instances : [
        for rule_key, rule in ws.firewall_rules : {
          ws_key     = ws_key
          rule_key   = rule_key
          rule_value = rule
        }
      ]
      ]) : "${pair.ws_key}-${pair.rule_key}" => {
      ws_key = pair.ws_key
      rule   = pair.rule_value
    }
    if var.enable_synapse_sql_pool
  }

  name                 = split("-", each.key)[1]
  synapse_workspace_id = azurerm_synapse_workspace.main[each.value.ws_key].id
  start_ip_address     = each.value.rule.start_ip
  end_ip_address       = each.value.rule.end_ip
}

# Synapse SQL Pool (Dedicated SQL Pool - formerly SQL Data Warehouse)
resource "azurerm_synapse_sql_pool" "main" {
  for_each             = var.enable_synapse_sql_pool ? var.synapse_instances : {}
  name                 = each.value.sql_pool_name
  synapse_workspace_id = azurerm_synapse_workspace.main[each.key].id
  sku_name             = each.value.sql_pool_sku
  create_mode          = "Default"
  collation            = each.value.sql_pool_collation
  storage_account_type = "LRS"
  # Disable geo backup when using LRS storage (not supported)
  geo_backup_policy_enabled = false
  # data_encrypted = true  # Transparent Data Encryption

  tags = var.tags
}

# Private Endpoint for Synapse Workspace
resource "azurerm_private_endpoint" "synapse_sql" {
  for_each            = local.synapse_instances_with_pe
  name                = "${each.value.workspace_name}-pe-sql"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id

  private_service_connection {
    name                           = "${each.value.workspace_name}-psc-sql"
    private_connection_resource_id = azurerm_synapse_workspace.main[each.key].id
    is_manual_connection           = false
    subresource_names              = ["Sql"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.synapse_sql[0].id]
  }

  tags = var.tags
}

# Synapse Private Endpoint for Serverless SQL
resource "azurerm_private_endpoint" "synapse_sql_ondemand" {
  for_each = {
    for k, v in local.synapse_instances_with_pe : k => v
    if v.pe_enable_sql_ondemand
  }
  name                = "${each.value.workspace_name}-pe-ondemand"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id

  private_service_connection {
    name                           = "${each.value.workspace_name}-psc-ondemand"
    private_connection_resource_id = azurerm_synapse_workspace.main[each.key].id
    is_manual_connection           = false
    subresource_names              = ["SqlOnDemand"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.synapse_sql[0].id]
  }

  tags = var.tags
}

# Synapse Private Endpoint for Dev/Web
resource "azurerm_private_endpoint" "synapse_dev" {
  for_each = {
    for k, v in local.synapse_instances_with_pe : k => v
    if v.pe_enable_dev
  }
  name                = "${each.value.workspace_name}-pe-dev"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id

  private_service_connection {
    name                           = "${each.value.workspace_name}-psc-dev"
    private_connection_resource_id = azurerm_synapse_workspace.main[each.key].id
    is_manual_connection           = false
    subresource_names              = ["Dev"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.synapse_dev[0].id]
  }

  tags = var.tags
}

# Private DNS Zones for Synapse
resource "azurerm_private_dns_zone" "synapse_sql" {
  count               = length(local.synapse_instances_with_pe) > 0 ? 1 : 0
  name                = "privatelink.sql.azuresynapse.net"
  resource_group_name = local.resource_group_name
}

resource "azurerm_private_dns_zone" "synapse_dev" {
  count               = length([for k, v in local.synapse_instances_with_pe : v if v.pe_enable_dev]) > 0 ? 1 : 0
  name                = "privatelink.azuresynapse.net"
  resource_group_name = local.resource_group_name
}

# VNet Links for Synapse DNS zones
resource "azurerm_private_dns_zone_virtual_network_link" "synapse_sql_link" {
  count                 = length(local.synapse_instances_with_pe) > 0 ? 1 : 0
  name                  = "${var.environment}-synapse-sql-dnslink"
  resource_group_name   = local.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_sql[0].name
  virtual_network_id    = local.vnet_id
  registration_enabled  = false
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_dev_link" {
  count                 = length([for k, v in local.synapse_instances_with_pe : v if v.pe_enable_dev]) > 0 ? 1 : 0
  name                  = "${var.environment}-synapse-dev-dnslink"
  resource_group_name   = local.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_dev[0].name
  virtual_network_id    = local.vnet_id
  registration_enabled  = false
}

# Role Assignment - Grant Synapse Workspace managed identity access to storage
resource "azurerm_role_assignment" "synapse_storage_blob_contributor" {
  for_each             = var.enable_synapse_sql_pool ? var.synapse_instances : {}
  scope                = azurerm_storage_account.synapse[each.key].id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_synapse_workspace.main[each.key].identity[0].principal_id
}

# Optional: Azure AD Group RBAC for Synapse Workspace
resource "azurerm_role_assignment" "synapse_admin_group" {
  for_each             = var.enable_synapse_sql_pool && var.enable_ad_groups && var.admin_group_name != null ? var.synapse_instances : {}
  scope                = azurerm_synapse_workspace.main[each.key].id
  role_definition_name = "Synapse Administrator"
  principal_id         = data.azuread_group.admin_group[0].object_id
}

resource "azurerm_role_assignment" "synapse_readonly_group" {
  for_each             = var.enable_synapse_sql_pool && var.enable_ad_groups && var.readonly_group_name != null ? var.synapse_instances : {}
  scope                = azurerm_synapse_workspace.main[each.key].id
  role_definition_name = "Synapse Monitoring Operator"
  principal_id         = data.azuread_group.readonly_group[0].object_id
}



# Diagnostics: Synapse Workspace
resource "azurerm_monitor_diagnostic_setting" "synapse_workspace" {
  for_each                   = var.enable_synapse_sql_pool && var.enable_diagnostics && var.log_analytics_workspace_id != null && length(var.synapse_workspace_diag_log_categories) > 0 ? var.synapse_instances : {}
  name                       = "${each.value.workspace_name}-diag"
  target_resource_id         = azurerm_synapse_workspace.main[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  dynamic "enabled_log" {
    for_each = var.synapse_workspace_diag_log_categories
    content {
      category = enabled_log.value
    }
  }
}

# Diagnostics: Synapse SQL Pool
resource "azurerm_monitor_diagnostic_setting" "synapse_sql_pool" {
  for_each                   = var.enable_synapse_sql_pool && var.enable_diagnostics && var.log_analytics_workspace_id != null && length(var.synapse_sql_pool_diag_log_categories) > 0 ? var.synapse_instances : {}
  name                       = "${each.value.sql_pool_name}-diag"
  target_resource_id         = azurerm_synapse_sql_pool.main[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  dynamic "enabled_log" {
    for_each = var.synapse_sql_pool_diag_log_categories
    content {
      category = enabled_log.value
    }
  }
}

# Diagnostics: Storage Account backing Synapse
resource "azurerm_monitor_diagnostic_setting" "synapse_storage_account" {
  for_each                   = var.enable_synapse_sql_pool && var.enable_diagnostics && var.log_analytics_workspace_id != null && length(var.storage_account_diag_log_categories) > 0 ? var.synapse_instances : {}
  name                       = "${each.value.storage_account_name}-diag"
  target_resource_id         = azurerm_storage_account.synapse[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  dynamic "enabled_log" {
    for_each = var.storage_account_diag_log_categories
    content {
      category = enabled_log.value
    }
  }
}
