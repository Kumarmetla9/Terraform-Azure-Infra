# Production Environment Variables

# Resource Configuration - Can use existing or create new
resource_group_name = "rg-caremore-prod" # Existing RG created by network module
location            = "East US"
environment         = "prod"

# Network Configuration - Example using existing network (set IDs) or new network (set to null)
vnet_name               = "vnet-caremore-prod"
vnet_id                 = null # Resolved from network remote state
vnet_address_space      = ["10.121.0.0/16"]
subnet_name             = "subnet-private-caremore-prod"
subnet_id               = null # Resolved from network remote state's private subnet
subnet_address_prefixes = ["10.121.2.0/23"]

# Network Security Group - Generic variables for any NSG
existing_nsg_id      = null
existing_nsg_name    = null
use_existing_network = true # Consume network from terraform-network-code

# Tags
tags = {
  Environment = "prod"
  Project     = "caremore-prod"
  Owner       = "TG-Mosaic-Cloud Infrastructure"
  CostCenter  = "Caremore"
  CreatedBy   = "Terraform"
}

# Windows VM Configuration
windows_vm_name        = "vm-windows-prod"
windows_vm_size        = "Standard_D2s_v3"
windows_admin_username = "azureadmin"
# windows_admin_password               = "Set via environment variable TF_VAR_windows_admin_password"
windows_os_disk_storage_account_type = "Premium_LRS"
windows_image_sku                    = "2022-Datacenter"

# Linux VM Configuration
linux_vm_name        = "vm-linux-prod"
linux_vm_size        = "Standard_D2s_v3"
linux_admin_username = "azureadmin"
# linux_admin_password                 = "Set via environment variable TF_VAR_linux_admin_password"
disable_password_authentication = true # Use SSH keys in production
# linux_ssh_public_key                 = "Set via environment variable TF_VAR_linux_ssh_public_key"
linux_os_disk_storage_account_type = "Premium_LRS"
linux_image_sku                    = "20_04-lts-gen2"

# Security Configuration (Restrictive for production)
allow_rdp_from_internet = false
allow_ssh_from_internet = false
allowed_ip_ranges = [
  "203.0.113.0/24", # Replace with your office IP range
  "198.51.100.0/24" # Replace with your VPN IP range
]

# Storage Configuration
create_data_disks              = true
data_disk_size_gb              = 128
data_disk_storage_account_type = "Premium_LRS"