# Development Environment Variables

# Resource Configuration - Import from terraform-network-code
# Use the same Resource Group as the network state to avoid cross-RG lookups
resource_group_name = "RG-Platform-caremore-dev"
location            = "eastus"
environment         = "dev"

# Network Configuration - Import from terraform-network-code
# Values aligned to terraform-network-code state (RG-Platform-caremore-dev / VNET-Platform-caremore-dev)
vnet_name               = "VNET-Platform-caremore-dev"
vnet_id                 = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev"
vnet_address_space      = ["10.111.0.0/16"]
subnet_name             = "SUBNET-PRIVATE-caremore-dev"
subnet_id               = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
subnet_address_prefixes = ["10.111.2.0/24"]

# Network Security Group - Import from terraform-network-code (using database NSG as default)
existing_nsg_id      = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/networkSecurityGroups/NSG-PRIVATE-caremore-dev"
existing_nsg_name    = "NSG-PRIVATE-caremore-dev"
use_existing_network = true

# Tier-based Network Mapping (Dynamic subnet and NSG assignment)
# Explicitly set from terraform-network-code state
tier_subnet_mapping = {
  public  = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PUBLIC-caremore-dev"
  private = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
  bastion = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/AzureBastionSubnet"
}
tier_nsg_mapping = {
  public  = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/networkSecurityGroups/NSG-PUBLIC-caremore-dev"
  private = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/networkSecurityGroups/NSG-PRIVATE-caremore-dev"
  bastion = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/networkSecurityGroups/NSG-BASTION-caremore-dev"
}

# Tags - Aligned with network terraform standards
tags = {
  Environment = "dev"
  Project     = "caremore-dev"
  Owner       = "TG-Mosaic-Cloud Infrastructure"
  CostCenter  = "Caremore"
  CreatedBy   = "Terraform"
}

# Multiple Windows VMs Configuration (with tier-based networking)
windows_vms = {
  "win-sql-ssrs-01" = {
    vm_size                      = "Standard_B2s"
    admin_username               = "azureadmin"
    admin_password               = "ChangeMe123!"
    os_disk_storage_account_type = "Premium_LRS"

    # Number of data disks to create (1, 2, 3, or 4)
    data_disk_count                = 1
    data_disk_size_gb              = 128
    data_disk_storage_account_type = "Premium_LRS"
    tier                           = "private"
  }
}

# Multiple Linux VMs Configuration (with tier-based networking)
linux_vms = {
  "linux-poc-caremore-dev" = {
    vm_size                         = "Standard_B2s"
    admin_username                  = "azureadmin"
    admin_password                  = "ChangeMe123!"
    disable_password_authentication = false
    os_disk_storage_account_type    = "Premium_LRS"
    data_disk_count                 = 1
    data_disk_size_gb               = 64
    data_disk_storage_account_type  = "Premium_LRS"
    tier                            = "private"
  }
}

# Security Configuration (Bastion-Only Access - Enhanced Security)
allow_rdp_from_internet = false
allow_ssh_from_internet = false
allowed_ip_ranges       = ["10.111.4.0/26"]
# Storage Configuration
create_data_disks              = true
data_disk_size_gb              = 128
data_disk_storage_account_type = "Premium_LRS"

# Azure Bastion Configuration (Enabled in dedicated Bastion subnet with dedicated NSG)
enable_bastion = true
bastion_name   = "bastion-caremore-dev"
bastion_sku    = "Standard"

# Bastion NSG Configuration (Using dedicated Bastion NSG from terraform-network-code)
bastion_nsg_id   = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/networkSecurityGroups/NSG-BASTION-caremore-dev"
bastion_nsg_name = "NSG-BASTION-caremore-dev"

# Use existing Bastion subnet from network state
bastion_subnet_id = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/AzureBastionSubnet"

# Bastion Advanced Features (Enabled)
bastion_copy_paste_enabled     = true
bastion_file_copy_enabled      = true
bastion_ip_connect_enabled     = true
bastion_shareable_link_enabled = false
bastion_tunneling_enabled      = true

# Azure AD Groups Access Control Configuration
enable_ad_groups                      = true
admin_group_name                      = "caremore-dev-admin"
readonly_group_name                   = "caremore-dev-readonly"
admin_group_role                      = "Contributor"
readonly_group_role                   = "Reader"
use_infrastructure_resource_as_target = "bastion_host"

# =========================================
# Azure Synapse SQL Pool Configuration
# =========================================
enable_synapse_sql_pool = true

# Synapse Instances Configuration
synapse_instances = {
  synapse01 = {
    workspace_name           = "synapse-caremore-01"
    storage_account_name     = "syncaremoredev01"
    filesystem_name          = "synapse-fs-caremore-01"
    sql_pool_name            = "sqlpool_caremore_01"
    sql_admin_username       = "sqladmin01"
    sql_admin_password       = "ChangeMe123!Synapse01"
    storage_account_tier     = "Standard"
    storage_replication_type = "LRS"
    managed_vnet_enabled     = false
    sql_pool_sku             = "DW100c"
    sql_pool_collation       = "SQL_Latin1_General_CP1_CI_AS"
    aad_admin_login          = null
    aad_admin_object_id      = null
    aad_admin_tenant_id      = null
    firewall_rules = {
      "AllowVNet" = {
        start_ip = "10.111.0.0"
        end_ip   = "10.111.255.255"
      }
    }
    private_endpoint_enabled      = true
    private_endpoint_subnet_id    = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    pe_enable_dev                 = true
    pe_enable_sql_ondemand        = true
    public_network_access_enabled = false
  }
}

# =========================================
# Azure SQL Serverless Configuration
# =========================================
enable_sql_serverless = true

sql_serverless_instances = {
  sql01 = {
    server_name              = "sql-serverless-caremore-01"
    database_name            = "sqldb-serverless-01"
    sql_admin_username       = "sqladmin01"
    sql_admin_password       = "ChangeMe123!Sql01"
    server_version           = "12.0"
    minimum_capacity         = 0.5
    max_size_bytes           = 34359738368 # 32GB
    auto_pause_delay_minutes = 60
    aad_admin_login          = null
    aad_admin_object_id      = null
    aad_admin_tenant_id      = null
    firewall_rules = {
      "AllowVNet" = {
        start_ip = "10.111.0.0"
        end_ip   = "10.111.255.255"
      }
    }
    private_endpoint_enabled      = true
    private_endpoint_subnet_id    = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    public_network_access_enabled = false
    enable_high_availability      = false
    zone_redundant                = false
    geo_backup_enabled            = true
    backup_retention_days         = 7
    diagnostic_settings_enabled   = true
  }
}

# =========================================
# Azure Storage Account Configuration
# Single storage account with multiple file shares (C, D, E, F, G, H drives)
# =========================================
enable_storage_account = true

storage_accounts = {
  platform01 = {
    storage_account_name          = "stplatformcaremoredev"
    account_tier                  = "Standard"
    replication_type              = "ZRS"
    account_kind                  = "StorageV2"
    min_tls_version               = "TLS1_2"
    public_network_access_enabled = true
    allow_blob_public_access      = false
    shared_access_key_enabled     = true
    enable_versioning             = true
    soft_delete_days              = 7
    enable_data_lake_gen2         = true

    # Network settings - Allow access from all authorized IP ranges
    network_default_action = "Deny"
    allowed_ip_ranges = []
    allowed_subnet_ids = [
      "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    ]
    network_bypass = ["AzureServices"]

    # Private endpoint
    private_endpoint_enabled   = true
    private_endpoint_subnet_id = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    pe_enable_blob             = true
    pe_enable_file             = true
    pe_enable_queue            = false

    # File shares - Multiple drives (C, D, E, F, G, H)
    file_shares = {
      c_drive = {
        name                       = "c-drive"
        quota_gb                   = 2048
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
      d_drive = {
        name                       = "d-drive"
        quota_gb                   = 3072
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
      e_drive = {
        name                       = "e-drive"
        quota_gb                   = 4096
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
      f_drive = {
        name                       = "f-drive"
        quota_gb                   = 2048
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
      g_drive = {
        name                       = "g-drive"
        quota_gb                   = 5120
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
      h_drive = {
        name                       = "h-drive"
        quota_gb                   = 1024
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
    }

    rbac_blob_readers      = {}
    rbac_blob_contributors = {}
    rbac_file_readers      = {}
    rbac_file_contributors = {}
    enable_resource_lock   = true
  }

  # Storage account created from snapshots (Disaster Recovery / Clone)
  platform01_dr = {
    storage_account_name          = "stplatformdrcaremoredev-copy"
    account_tier                  = "Standard"
    replication_type              = "ZRS"
    account_kind                  = "StorageV2"
    min_tls_version               = "TLS1_2"
    public_network_access_enabled = true
    allow_blob_public_access      = false
    shared_access_key_enabled     = true
    enable_versioning             = true
    soft_delete_days              = 7
    enable_data_lake_gen2         = false

    # Network settings
    network_default_action = "Deny"
    allowed_ip_ranges = []
    allowed_subnet_ids = [
      "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    ]
    network_bypass = ["AzureServices"]

    # Private endpoint
    private_endpoint_enabled   = true
    private_endpoint_subnet_id = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    pe_enable_blob             = true
    pe_enable_file             = true
    pe_enable_queue            = false

    # File shares restored from snapshots
    # Replace snapshot_id with actual snapshot URL from source storage account
    # Get snapshot URL: az storage share list --account-name stplatformcaremoredev --include-snapshots
    # Format: https://stplatformcaremoredev.file.core.windows.net/c-drive?snapshot=2025-11-18T10:30:00.0000000Z
    file_shares = {
      c_drive_restored = {
        name                       = "c-drive-restored"
        quota_gb                   = 2048
        snapshot_id                = null # "https://stplatformcaremoredev.file.core.windows.net/c-drive?snapshot=2025-11-18T10:30:00.0000000Z"
        source_storage_account_id  = null # "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Storage/storageAccounts/stplatformcaremoredev"
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
      d_drive_restored = {
        name                       = "d-drive-restored"
        quota_gb                   = 3072
        snapshot_id                = null # Set to actual snapshot URL to restore
        source_storage_account_id  = null
        rbac_readers               = {}
        rbac_contributors          = {}
        rbac_elevated_contributors = {}
      }
    }

    rbac_blob_readers      = {}
    rbac_blob_contributors = {}
    rbac_file_readers      = {}
    rbac_file_contributors = {}
    enable_resource_lock   = false
  }
}

# =========================================
# Azure SQL Elastic Pool Configuration
# =========================================
enable_sql_elastic_pool = true

sql_elastic_instances = {
  elastic01 = {
    server_name              = "sql-elastic-caremore-01"
    elastic_pool_name        = "elasticpool-caremore-01"
    sql_admin_username       = "sqladmin01"
    sql_admin_password       = "ChangeMe123!Elastic01"
    server_version           = "12.0"
    elastic_pool_max_size_gb = 50
    elastic_pool_sku = {
      name     = "StandardPool"
      tier     = "Standard"
      capacity = 50
    }
    databases = {
      "db01" = {
        name                  = "sqldb-elastic-01"
        collation             = "SQL_Latin1_General_CP1_CI_AS"
        max_size_gb           = 32
        min_capacity          = 0
        max_capacity          = 50
        zone_redundant        = false
        backup_retention_days = 7
      },
      "db02" = {
        name                  = "sqldb-elastic-02"
        collation             = "SQL_Latin1_General_CP1_CI_AS"
        max_size_gb           = 32
        min_capacity          = 0
        max_capacity          = 50
        zone_redundant        = false
        backup_retention_days = 7
      }
    }
    aad_admin_login     = null
    aad_admin_object_id = null
    aad_admin_tenant_id = null
    firewall_rules = {
      "AllowVNet" = {
        start_ip = "10.111.0.0"
        end_ip   = "10.111.255.255"
      }
    }
    private_endpoint_enabled      = true
    private_endpoint_subnet_id    = "/subscriptions/b198900a-d66c-4291-b14a-10b6ed4a76d4/resourceGroups/RG-Platform-caremore-dev/providers/Microsoft.Network/virtualNetworks/VNET-Platform-caremore-dev/subnets/SUBNET-PRIVATE-caremore-dev"
    public_network_access_enabled = false
    enable_high_availability      = false
    zone_redundant                = false
    geo_backup_enabled            = true
    diagnostic_settings_enabled   = true
  }
}