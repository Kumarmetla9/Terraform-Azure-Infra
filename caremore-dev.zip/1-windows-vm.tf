# Multiple Windows VMs Configuration

# Create multiple Windows VMs based on the windows_vms variable
# Legacy single VM support: if windows_vms is empty but legacy variables are set, create single VM
locals {
  # Tier mapping provided via variables (public/private/bastion)
  tier_subnet_map = var.tier_subnet_mapping

  tier_nsg_map = var.tier_nsg_mapping
  # Merge legacy single VM config with multiple VMs config
  all_windows_vms = merge(
    var.windows_vms,
    # Add legacy single VM if windows_vms is empty and legacy vm_name is not default and password is provided
    length(var.windows_vms) == 0 && var.windows_vm_name != "vm-windows" && var.windows_admin_password != null ? {
      "${var.windows_vm_name}" = {
        vm_size                        = var.windows_vm_size
        admin_username                 = var.windows_admin_username
        admin_password                 = var.windows_admin_password
        os_disk_storage_account_type   = var.windows_os_disk_storage_account_type
        os_disk_caching                = var.windows_os_disk_caching
        image_sku                      = var.windows_image_sku
        image_publisher                = var.windows_image_publisher
        image_offer                    = var.windows_image_offer
        image_version                  = var.windows_image_version
        create_data_disk               = var.create_data_disks
        data_disk_size_gb              = var.data_disk_size_gb
        data_disk_storage_account_type = var.data_disk_storage_account_type
      }
    } : {}
  )
}

// Create a safe, non-sensitive projection of per-VM network settings to avoid
// propagating sensitive VM fields (like admin_password) into locals used for
// resource keys/for_each expressions.
locals {
  windows_vms_safe = {
    for vm_name, vm_cfg in var.windows_vms :
    vm_name => {
      nsg_id           = try(vm_cfg.nsg_id, null)
      subnet_id        = try(vm_cfg.subnet_id, null)
      tier             = try(vm_cfg.tier, "private")
      create_data_disk = try(vm_cfg.create_data_disk, false)
    }
  }
}

# Windows VMs are private - no public IPs (access via Azure Bastion)
# Public IP resources removed for security

# Dynamic NSG and Subnet selection per VM
locals {
  # Default NSG (backward compatibility) - use existing NSG variables
  default_windows_nsg_id = var.use_existing_network && var.existing_nsg_id != null ? var.existing_nsg_id : null

  # Default subnet (backward compatibility)
  default_windows_subnet_id = local.subnet_id

  # Per-VM NSG selection with priority: VM-specific > tier-based > default
  windows_vm_nsg_mapping = {
    for vm_name, vm_config in local.windows_vms_safe :
    vm_name => coalesce(
      vm_config.nsg_id,                                 # 1. VM-specific NSG ID
      lookup(local.tier_nsg_map, vm_config.tier, null), # 2. Tier-based NSG mapping (includes remote state)
      local.default_windows_nsg_id                      # 3. Default NSG
    )
  }

  # Per-VM subnet selection with priority: VM-specific > tier-based > default
  windows_vm_subnet_mapping = {
    for vm_name, vm_config in local.windows_vms_safe :
    vm_name => coalesce(
      vm_config.subnet_id,                                 # 1. VM-specific subnet ID
      lookup(local.tier_subnet_map, vm_config.tier, null), # 2. Tier-based subnet mapping (includes remote state)
      local.default_windows_subnet_id                      # 3. Default subnet
    )
  }
}

# Network Interface for Windows VMs
resource "azurerm_network_interface" "windows_vm_nic" {
  # iterate by VM name only (non-sensitive keys) to avoid pulling sensitive vm attributes into for_each
  for_each            = { for k in keys(var.windows_vms) : k => k }
  name                = "${each.key}-nic"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = local.windows_vm_subnet_mapping[each.key]
    private_ip_address_allocation = "Static" # Changed to Static to preserve IP on recreation
    # lookup from the original variable map for potential custom IPs
    private_ip_address = lookup(var.windows_vms[each.key], "private_ip_address", null)
    # No public IP - VMs are private, accessed via Azure Bastion
  }

  tags = var.tags

  # Preserve NIC when VM is recreated
  lifecycle {
    ignore_changes = [
      tags["CreatedDate"] # Ignore timestamp changes
    ]
  }
}

# Associate Network Security Group to Network Interface
resource "azurerm_network_interface_security_group_association" "windows_vm_nsg_association" {
  # Iterate VM names (non-sensitive) and create association only where we resolved an NSG
  for_each = { for k in keys(var.windows_vms) : k => k if lookup(local.windows_vm_nsg_mapping, k, null) != null }

  network_interface_id      = azurerm_network_interface.windows_vm_nic[each.key].id
  network_security_group_id = local.windows_vm_nsg_mapping[each.key]
}

# Windows Virtual Machines
resource "azurerm_windows_virtual_machine" "main" {
  for_each            = var.windows_vms
  name                = each.key
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  size                = each.value.vm_size
  admin_username      = each.value.admin_username
  admin_password      = each.value.admin_password

  # Disable automatic patching and provision VM agent
  patch_mode         = "Manual"
  provision_vm_agent = true

  network_interface_ids = [
    azurerm_network_interface.windows_vm_nic[each.key].id,
  ]

  os_disk {
    caching              = each.value.os_disk_caching
    storage_account_type = each.value.os_disk_storage_account_type
  }

  source_image_reference {
    publisher = each.value.image_publisher
    offer     = each.value.image_offer
    sku       = each.value.image_sku
    version   = each.value.image_version
  }

  tags = var.tags

  # Lifecycle configuration to prevent unwanted recreation
  lifecycle {
    ignore_changes = [
      tags["CreatedDate"], # Ignore timestamp changes
      # Uncomment below to ignore minor version changes that don't require recreation
      # source_image_reference[0].version,
    ]
  }
}

# Data disk for Windows VMs (optional)
resource "azurerm_managed_disk" "windows_vm_data_disk" {
  for_each             = { for k, v in var.windows_vms : k => v if v.create_data_disk }
  name                 = "${each.key}-data-disk"
  location             = local.resource_group_location
  resource_group_name  = local.resource_group_name
  storage_account_type = each.value.data_disk_storage_account_type
  create_option        = "Empty"
  disk_size_gb         = each.value.data_disk_size_gb

  tags = var.tags

  # CRITICAL: Protect data disk from accidental deletion
  lifecycle {
    prevent_destroy = true # Prevents Terraform from destroying this disk
    ignore_changes = [
      tags["CreatedDate"] # Ignore timestamp changes
    ]
  }
}

# Attach data disk to Windows VMs
resource "azurerm_virtual_machine_data_disk_attachment" "windows_vm_data_disk_attachment" {
  for_each           = { for k, v in var.windows_vms : k => v if v.create_data_disk }
  managed_disk_id    = azurerm_managed_disk.windows_vm_data_disk[each.key].id
  virtual_machine_id = azurerm_windows_virtual_machine.main[each.key].id
  lun                = "10"
  caching            = "ReadWrite"
}

# Custom Script Extension for Windows VMs (optional initialization)
resource "azurerm_virtual_machine_extension" "windows_vm_extension" {
  for_each             = var.windows_vms
  name                 = "${each.key}-extension"
  virtual_machine_id   = azurerm_windows_virtual_machine.main[each.key].id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"

  settings = jsonencode({
    "commandToExecute" = "powershell -ExecutionPolicy Unrestricted -Command \"Write-Host 'Windows VM ${each.key} initialized successfully (Size: ${each.value.vm_size})'; Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, TotalPhysicalMemory\""
  })

  tags = var.tags
}

# =========================================
# Azure Monitor Agent (Windows) + DCR for VM diagnostics
# =========================================

# Install Azure Monitor Agent on Windows VMs
resource "azurerm_virtual_machine_extension" "ama_windows" {
  for_each = var.enable_vm_diagnostics && var.log_analytics_workspace_id != null ? azurerm_windows_virtual_machine.main : {}

  name                      = "${each.key}-azuremonitoragent"
  virtual_machine_id        = each.value.id
  publisher                 = "Microsoft.Azure.Monitor"
  type                      = "AzureMonitorWindowsAgent"
  type_handler_version      = "1.0"
  automatic_upgrade_enabled = true

  settings = jsonencode({})
}

# Data Collection Rule sending to Log Analytics (single per environment)
resource "azurerm_monitor_data_collection_rule" "vm" {
  count               = var.enable_vm_diagnostics && var.log_analytics_workspace_id != null ? 1 : 0
  name                = "dcr-${var.environment}-vm"
  resource_group_name = local.resource_group_name
  location            = local.resource_group_location

  destinations {
    log_analytics {
      name                  = "law"
      workspace_resource_id = var.log_analytics_workspace_id
    }
  }

  data_sources {
    syslog {
      name           = "syslog"
      streams        = ["Microsoft-Syslog"]
      facility_names = var.syslog_facilities
      log_levels     = var.syslog_levels
    }

    performance_counter {
      name                          = "perf"
      streams                       = ["Microsoft-Perf"]
      sampling_frequency_in_seconds = 60
      counter_specifiers            = var.vm_perf_counters
    }
  }

  data_flow {
    streams      = ["Microsoft-Syslog", "Microsoft-Perf"]
    destinations = ["law"]
  }
}

# Associate DCR with Windows VMs
resource "azurerm_monitor_data_collection_rule_association" "vm_windows" {
  for_each = var.enable_vm_diagnostics && var.log_analytics_workspace_id != null ? azurerm_windows_virtual_machine.main : {}

  name                    = "${each.key}-dcr-assoc"
  target_resource_id      = each.value.id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.vm[0].id
  description             = "Associate DCR to Windows VM"
}