

# Terraform Infrastructure Code

This Terraform module manages the core infrastructure resources for Azure environments including virtual machines, databases, analytics, and security configurations. This module depends on the network infrastructure created by terraform-network-code.

## Overview

This module deploys and manages:
- Windows and Linux Virtual Machines
- Azure Bastion for secure VM access
- Azure Synapse Analytics with SQL Pools
- Azure SQL Serverless databases
- Azure SQL Elastic Pools
- Azure AD RBAC assignments

**Deployment Order**: This module should be deployed **after** terraform-network-code as it depends on existing network resources.

## Resources Created

### Compute Resources
- **Windows VMs**: Windows Server 2022 virtual machines with data disks
- **Linux VMs**: Ubuntu 20.04 LTS virtual machines with data disks
- **Azure Bastion**: Secure RDP/SSH access to VMs without public IPs

### Database & Analytics
- **Azure Synapse Workspace**: Data warehouse and analytics platform
- **Synapse SQL Pools**: Dedicated SQL pools for data warehousing
- **Azure SQL Serverless**: Auto-scaling serverless SQL databases
- **Azure SQL Elastic Pools**: Shared resource pools for multiple databases

### Security & Access
- **Azure AD Groups**: Role-based access control assignments
- **Private Endpoints**: Secure connectivity to SQL and Synapse
- **Network Security**: Integration with existing NSGs

## File Structure

```
terraform-Infrastructure-code/
├── provider.tf                   # Azure provider configuration
├── variables.tf                  # Variable definitions
├── main.tf                      # Main configuration and data sources
├── network-remote-state.tf      # Network dependency references
├── outputs.tf                   # Output values
├── 1-windows-vm.tf              # Windows VM resources
├── 2-linux-vm.tf                # Linux VM resources
├── 3-bastion.tf                 # Azure Bastion configuration
├── 4-synapse-sql-pool.tf        # Synapse Analytics resources
├── 5-azure-ad-rbac.tf           # Azure AD role assignments
├── 6-azure-sql-serverless.tf    # SQL Serverless databases
├── 7-azure-sql-elastic.tf       # SQL Elastic Pool configuration
├── caremore-dev.tfvars          # Dev environment value
└── README.md                    # This file
```

## Usage

### 1. Initialize Terraform

```bash
cd terraform-Infrastructure-code
terraform init
```

### 2. Plan Deployment

```bash
terraform plan -var-file="caremore-dev.tfvars"
```

### 3. Apply Configuration

```bash
terraform apply -var-file="caremore-dev.tfvars"
```

### 4. View Outputs

```bash
terraform output
```

## Resource Configurations

### Virtual Machines

#### Windows VMs
Configure Windows virtual machines with tier-based networking:

```hcl
windows_vms = {
  "win-sql-ssrs-01" = {
    vm_size                      = "Standard_B2s"
    os_disk_storage_account_type = "Premium_LRS"
    data_disk_count              = 1
    data_disk_size_gb           = 128
    tier                         = "private"
  }
}
```

#### Linux VMs
Configure Linux virtual machines:

```hcl
linux_vms = {
  "linux-poc-caremore-dev" = {
    vm_size                      = "Standard_B2s"
    disable_password_authentication = false
    tier                         = "private"
  }
}
```

### Azure Bastion

Secure VM access without public IPs:

```hcl
enable_bastion                 = true
bastion_name                   = "bastion-caremore-dev"
bastion_sku                    = "Standard"
bastion_copy_paste_enabled     = true
bastion_file_copy_enabled      = true
bastion_ip_connect_enabled     = true
bastion_tunneling_enabled      = true
```

### Azure Synapse SQL Pool

Data warehousing and analytics:

```hcl
synapse_instances = {
  synapse01 = {
    workspace_name          = "synapse-caremore-01"
    storage_account_name    = "syncaremoredev01"
    sql_pool_name          = "sqlpool_caremore_01"
    sql_pool_sku           = "DW100c"
    private_endpoint_enabled = true
  }
}
```

### SQL Serverless

Auto-scaling serverless databases:

```hcl
sql_serverless_instances = {
  sql01 = {
    server_name              = "sql-serverless-caremore-01"
    database_name           = "sqldb-serverless-01"
    minimum_capacity        = 0.5
    auto_pause_delay_minutes = 60
    private_endpoint_enabled = true
  }
}
```

### SQL Elastic Pool

Shared resource pools for multiple databases:

```hcl
sql_elastic_instances = {
  elastic01 = {
    server_name           = "sql-elastic-caremore-01"
    elastic_pool_name     = "elasticpool-caremore-01"
    elastic_pool_max_size_gb = 50
    elastic_pool_sku = {
      name     = "StandardPool"
      tier     = "Standard"
      capacity = 50
    }
    databases = {
      db01 = { name = "sqldb-elastic-01", max_size_gb = 32 }
      db02 = { name = "sqldb-elastic-02", max_size_gb = 32 }
    }
  }
}
```

## Tier-Based Networking

VMs and resources are deployed to specific network tiers:

- **public**: Public-facing subnet (web servers, load balancers)
- **private**: Internal subnet (databases, app servers)
- **bastion**: Azure Bastion subnet (secure access)

Configure tier mapping in tfvars:

```hcl
tier_subnet_mapping = {
  public  = "/subscriptions/.../subnets/SUBNET-PUBLIC-caremore-dev"
  private = "/subscriptions/.../subnets/SUBNET-PRIVATE-caremore-dev"
  bastion = "/subscriptions/.../subnets/AzureBastionSubnet"
}

tier_nsg_mapping = {
  public  = "/subscriptions/.../NSG-PUBLIC-caremore-dev"
  private = "/subscriptions/.../NSG-PRIVATE-caremore-dev"
  bastion = "/subscriptions/.../NSG-BASTION-caremore-dev"
}
```

## Outputs

Key outputs for reference and integration:

| Output | Description |
|--------|-------------|
| `windows_vm_ids` | Map of Windows VM names to IDs |
| `linux_vm_ids` | Map of Linux VM names to IDs |
| `bastion_id` | Azure Bastion resource ID |
| `synapse_workspace_ids` | Map of Synapse workspace IDs |
| `sql_server_ids` | Map of SQL Server IDs |
| `sql_database_ids` | Map of SQL Database IDs |

## Security Features

### Private Endpoints
- All SQL and Synapse resources use private endpoints
- No public network access to databases
- Traffic stays within VNet

### Network Security
- VMs deployed to private subnets by default
- No internet-facing IPs on VMs
- Access via Azure Bastion only

### Azure AD Integration
- Role-based access control (RBAC)
- Azure AD group assignments
- Least privilege access model

## Multiple Environments

Deploy to different environments using separate tfvars:

```bash
# Development
terraform apply -var-file="caremore-dev.tfvars"

```

## Maintenance

### Updating Resources
```bash
terraform plan -var-file="caremore-dev.tfvars"
terraform apply -var-file="caremore-dev.tfvars"
```

### Viewing Current State
```bash
terraform show
terraform state list
```

### Destroying Resources
```bash
# WARNING: This will delete all infrastructure resources
terraform destroy -var-file="caremore-dev.tfvars"
```

## Dependencies

**Required**:
- terraform-network-code (must be deployed first)
- Resource Group
- Virtual Network
- Subnets
- Network Security Groups

**Dependent modules**: None (this is the application layer)

## Resource Sizing Guidelines

## Tags

All resources are tagged with:
- `Environment`: dev/prod/staging
- `Project`: Project identifier
- `Owner`: Team responsible
- `CostCenter`: Billing tracking
- `CreatedBy`: Terraform

## License

Internal use only - Mosaic Health Platform Team

## Support

For issues or questions:
- Infrastructure Team: TG-Mosaic-Cloud Infrastructure
- Terraform Registry: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs

---