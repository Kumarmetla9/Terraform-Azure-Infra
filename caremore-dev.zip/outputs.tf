# Output values for VM Infrastructure

# Resource Group Outputs
output "resource_group_name" {
  description = "Name of the resource group"
  value       = local.resource_group_name
}

output "resource_group_location" {
  description = "Location of the resource group"
  value       = local.resource_group_location
}

# Network Outputs
output "virtual_network_name" {
  description = "Name of the virtual network"
  value       = local.vnet_name
}

output "virtual_network_id" {
  description = "ID of the virtual network"
  value       = local.vnet_id
}

output "subnet_name" {
  description = "Name of the subnet"
  value       = var.subnet_name
}

output "subnet_id" {
  description = "ID of the subnet"
  value       = local.subnet_id
}

# Multiple Windows VMs Outputs
output "windows_vms" {
  description = "Map of Windows VMs with their details"
  value = {
    for k, v in azurerm_windows_virtual_machine.main : k => {
      name           = v.name
      id             = v.id
      size           = v.size
      private_ip     = azurerm_network_interface.windows_vm_nic[k].private_ip_address
      admin_username = v.admin_username
    }
  }
}

output "windows_vm_names" {
  description = "List of Windows VM names"
  value       = [for vm in azurerm_windows_virtual_machine.main : vm.name]
}

output "windows_vm_private_ips" {
  description = "Map of Windows VM names to their private IP addresses"
  value       = { for k, v in azurerm_network_interface.windows_vm_nic : k => v.private_ip_address }
}

# Multiple Linux VMs Outputs
output "linux_vms" {
  description = "Map of Linux VMs with their details"
  value = {
    for k, v in azurerm_linux_virtual_machine.main : k => {
      name           = v.name
      id             = v.id
      size           = v.size
      private_ip     = azurerm_network_interface.linux_vm_nic[k].private_ip_address
      admin_username = v.admin_username
    }
  }
}

output "linux_vm_names" {
  description = "List of Linux VM names"
  value       = [for vm in azurerm_linux_virtual_machine.main : vm.name]
}

output "linux_vm_private_ips" {
  description = "Map of Linux VM names to their private IP addresses"
  value       = { for k, v in azurerm_network_interface.linux_vm_nic : k => v.private_ip_address }
}

# Security Group Information
output "windows_vm_nsg_mapping" {
  description = "Map of Windows VM names to their assigned NSG IDs"
  value       = local.all_windows_vms != null ? { for k, v in local.all_windows_vms : k => local.windows_vm_nsg_mapping[k] } : {}
  sensitive   = true
}

output "linux_vm_nsg_mapping" {
  description = "Map of Linux VM names to their assigned NSG IDs"
  value       = local.all_linux_vms != null ? { for k, v in local.all_linux_vms : k => local.vm_nsg_mapping[k] } : {}
}

# Data Disk Information (if created)
output "windows_vm_data_disks" {
  description = "Map of Windows VM data disk IDs"
  value       = { for k, v in azurerm_managed_disk.windows_vm_data_disk : k => v.id }
}

output "linux_vm_data_disks" {
  description = "Map of Linux VM data disk IDs"
  value       = { for k, v in azurerm_managed_disk.linux_vm_data_disk : k => v.id }
}

# Azure Bastion Information
output "bastion_host_id" {
  description = "ID of the Azure Bastion Host"
  value       = var.enable_bastion ? azurerm_bastion_host.main[0].id : null
}

output "bastion_host_name" {
  description = "Name of the Azure Bastion Host"
  value       = var.enable_bastion ? azurerm_bastion_host.main[0].name : null
}

output "bastion_host_fqdn" {
  description = "Fully Qualified Domain Name of the Azure Bastion Host"
  value       = var.enable_bastion ? azurerm_bastion_host.main[0].dns_name : null
}

output "bastion_public_ip" {
  description = "Public IP address of the Azure Bastion Host"
  value       = var.enable_bastion ? azurerm_public_ip.bastion_public_ip[0].ip_address : null
}

output "bastion_connection_info" {
  description = "Information on how to connect to VMs through Bastion"
  value = var.enable_bastion ? {
    azure_portal_method = "Navigate to Azure Portal -> Virtual Machines -> Select VM -> Connect -> Bastion"
    native_client_method = var.bastion_sku == "Standard" && var.bastion_tunneling_enabled ? {
      description         = "Use Azure CLI with native RDP/SSH clients"
      windows_rdp_example = "az network bastion rdp --name ${var.bastion_name} --resource-group ${local.resource_group_name} --target-resource-id <windows-vm-resource-id>"
      linux_ssh_example   = "az network bastion ssh --name ${var.bastion_name} --resource-group ${local.resource_group_name} --target-resource-id <linux-vm-resource-id> --auth-type password --username <admin-username>"
      } : {
      description         = "Not available (requires Standard SKU with tunneling enabled)"
      windows_rdp_example = null
      linux_ssh_example   = null
    }
    bastion_sku = var.bastion_sku
    enabled_features = var.bastion_sku == "Standard" ? [
      var.bastion_copy_paste_enabled ? "Copy/Paste" : null,
      var.bastion_file_copy_enabled ? "File Copy" : null,
      var.bastion_ip_connect_enabled ? "IP Connect" : null,
      var.bastion_shareable_link_enabled ? "Shareable Links" : null,
      var.bastion_tunneling_enabled ? "Native Client Support" : null
    ] : ["Basic Bastion Features"]
  } : null
}

output "bastion_subnet_id" {
  description = "ID of the Azure Bastion subnet"
  value       = var.enable_bastion ? local.bastion_subnet_id : null
}

# Azure AD Groups Access Control
output "ad_groups_access" {
  description = "Azure AD groups configured for infrastructure access"
  value = var.enable_ad_groups ? {
    admin_group = {
      name      = var.admin_group_name
      object_id = length(data.azuread_group.admin_group) > 0 ? data.azuread_group.admin_group[0].object_id : null
      role      = var.admin_group_role
    }
    readonly_group = {
      name      = var.readonly_group_name
      object_id = length(data.azuread_group.readonly_group) > 0 ? data.azuread_group.readonly_group[0].object_id : null
      role      = var.readonly_group_role
    }
    target_type = var.target_resource_id != null ? "custom" : var.use_infrastructure_resource_as_target
    target_resource = var.target_resource_id != null ? var.target_resource_id : (
      var.use_infrastructure_resource_as_target == "bastion_host" && var.enable_bastion ?
      "bastion_host_configured" :
      var.use_infrastructure_resource_as_target
    )
  } : null
}

# Summary Output
output "deployment_summary" {
  description = "Summary of the deployed resources"
  sensitive   = true
  value = {
    resource_group    = local.resource_group_name
    location          = local.resource_group_location
    environment       = var.environment
    total_vms         = length(local.all_windows_vms) + length(local.all_linux_vms)
    windows_vms_count = length(local.all_windows_vms)
    linux_vms_count   = length(local.all_linux_vms)
    windows_vms = {
      for k, v in azurerm_windows_virtual_machine.main : k => {
        size       = v.size
        private_ip = azurerm_network_interface.windows_vm_nic[k].private_ip_address
      }
    }
    linux_vms = {
      for k, v in azurerm_linux_virtual_machine.main : k => {
        size       = v.size
        private_ip = azurerm_network_interface.linux_vm_nic[k].private_ip_address
      }
    }
    network = {
      vnet_name              = local.vnet_name
      subnet_name            = var.subnet_name
      subnet_id              = local.subnet_id
      using_existing_network = true
    }
    bastion = var.enable_bastion ? {
      name      = azurerm_bastion_host.main[0].name
      fqdn      = azurerm_bastion_host.main[0].dns_name
      public_ip = azurerm_public_ip.bastion_public_ip[0].ip_address
      sku       = var.bastion_sku
    } : null
    ad_groups = var.enable_ad_groups ? {
      enabled        = true
      admin_group    = var.admin_group_name
      readonly_group = var.readonly_group_name
      target_type    = var.target_resource_id != null ? "custom" : var.use_infrastructure_resource_as_target
    } : { enabled = false }
    synapse = var.enable_synapse_sql_pool ? {
      workspace_name = azurerm_synapse_workspace.main["synapse01"].name
      sql_pool_name  = azurerm_synapse_sql_pool.main["synapse01"].name
      sql_pool_sku   = var.synapse_sql_pool_sku
    } : null
  }
}

# =========================================
# Azure Synapse SQL Pool Outputs
# =========================================

output "synapse_workspace_id" {
  description = "ID of the Synapse Workspace"
  value       = var.enable_synapse_sql_pool ? azurerm_synapse_workspace.main["synapse01"].id : null
}

output "synapse_workspace_name" {
  description = "Name of the Synapse Workspace"
  value       = var.enable_synapse_sql_pool ? azurerm_synapse_workspace.main["synapse01"].name : null
}

output "synapse_workspace_connectivity_endpoints" {
  description = "Connectivity endpoints for Synapse Workspace"
  value       = var.enable_synapse_sql_pool ? azurerm_synapse_workspace.main["synapse01"].connectivity_endpoints : null
}

output "synapse_sql_pool_id" {
  description = "ID of the Synapse SQL Pool"
  value       = var.enable_synapse_sql_pool ? azurerm_synapse_sql_pool.main["synapse01"].id : null
}

output "synapse_sql_pool_name" {
  description = "Name of the Synapse SQL Pool"
  value       = var.enable_synapse_sql_pool ? azurerm_synapse_sql_pool.main["synapse01"].name : null
}

output "synapse_sql_pool_sku" {
  description = "SKU of the Synapse SQL Pool"
  value       = var.enable_synapse_sql_pool ? var.synapse_sql_pool_sku : null
}

output "synapse_storage_account_name" {
  description = "Name of the storage account for Synapse Data Lake"
  value       = var.enable_synapse_sql_pool ? azurerm_storage_account.synapse["synapse01"].name : null
}

output "synapse_storage_account_id" {
  description = "ID of the storage account for Synapse Data Lake"
  value       = var.enable_synapse_sql_pool ? azurerm_storage_account.synapse["synapse01"].id : null
}

output "synapse_storage_primary_endpoint" {
  description = "Primary endpoint of the Synapse storage account"
  value       = var.enable_synapse_sql_pool ? azurerm_storage_account.synapse["synapse01"].primary_blob_endpoint : null
}

output "synapse_connection_info" {
  description = "Connection information for Synapse SQL Pool"
  value = var.enable_synapse_sql_pool ? {
    sql_pool_name              = azurerm_synapse_sql_pool.main["synapse01"].name
    workspace_name             = azurerm_synapse_workspace.main["synapse01"].name
    admin_username             = var.synapse_sql_admin_username
    sql_endpoint               = "${azurerm_synapse_workspace.main["synapse01"].name}.sql.azuresynapse.net"
    serverless_endpoint        = "${azurerm_synapse_workspace.main["synapse01"].name}-ondemand.sql.azuresynapse.net"
    connection_string_template = "Server=tcp:${azurerm_synapse_workspace.main["synapse01"].name}.sql.azuresynapse.net,1433;Initial Catalog=${azurerm_synapse_sql_pool.main["synapse01"].name};Persist Security Info=False;User ID=${var.synapse_sql_admin_username};Password={your_password};MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
    synapse_studio_url         = "https://web.azuresynapse.net?workspace=%2fsubscriptions%2f${data.azurerm_client_config.current.subscription_id}%2fresourceGroups%2f${local.resource_group_name}%2fproviders%2fMicrosoft.Synapse%2fworkspaces%2f${azurerm_synapse_workspace.main["synapse01"].name}"
    sku                        = var.synapse_sql_pool_sku
  } : null
  sensitive = true
}

output "synapse_managed_identity" {
  description = "Managed identity of the Synapse Workspace"
  value = var.enable_synapse_sql_pool ? {
    principal_id = azurerm_synapse_workspace.main["synapse01"].identity[0].principal_id
    tenant_id    = azurerm_synapse_workspace.main["synapse01"].identity[0].tenant_id
  } : null
}

# =========================================
# Azure SQL Serverless Outputs
# =========================================

output "sql_serverless_summary" {
  description = "Summary of SQL Serverless deployment"
  value = var.enable_sql_serverless ? {
    total_instances = length(var.sql_serverless_instances)
    instances = {
      for k, v in var.sql_serverless_instances : k => {
        server_name   = v.server_name
        database_name = v.database_name
        capacity      = "${v.minimum_capacity} vCore"
        max_size      = "${v.max_size_bytes / (1024 * 1024 * 1024)} GB"
        auto_pause    = v.auto_pause_delay_minutes
      }
    }
  } : null
}

output "sql_serverless_servers" {
  description = "Map of SQL Serverless servers with their details"
  value = {
    for k, v in azurerm_mssql_server.serverless : k => {
      name           = v.name
      id             = v.id
      fqdn           = "${v.name}.database.windows.net"
      admin_login    = v.administrator_login
      version        = v.version
      location       = v.location
      identity       = try(v.identity[0].type, null)
      public_access  = v.public_network_access_enabled
      minimum_tls    = v.minimum_tls_version
      aad_admin      = try(v.azuread_administrator[0].login_username, null)
      resource_group = v.resource_group_name
    }
  }
  sensitive = true
}

output "sql_serverless_databases" {
  description = "Map of SQL Serverless databases with their details"
  value = {
    for k, v in azurerm_mssql_database.serverless : k => {
      name                  = v.name
      id                    = v.id
      server_name           = split("/", v.server_id)[8]
      max_size_gb           = v.max_size_gb
      min_capacity          = v.min_capacity
      auto_pause_delay      = v.auto_pause_delay_in_minutes
      status                = "Serverless"
      license_type          = v.license_type
      read_scale            = try(v.read_scale, false)
      geo_backup_enabled    = try(v.geo_backup_enabled, true)
      zone_redundant        = try(v.zone_redundant, false)
      backup_retention_days = try(v.backup_retention_days, 7)
      tags                  = v.tags
    }
  }
}

output "sql_serverless_private_endpoints" {
  description = "Map of SQL Serverless private endpoints"
  value = {
    for k, v in azurerm_private_endpoint.sql_serverless : k => {
      name = v.name
      id   = v.id
      private_service_connection = {
        name      = v.private_service_connection[0].name
        status    = v.private_service_connection[0].private_connection_resource_id
        is_manual = v.private_service_connection[0].is_manual_connection
      }
      subnet_id = v.subnet_id
      location  = v.location
      dns_zones = try(v.private_dns_zone_group[0].private_dns_zone_ids, [])
      tags      = v.tags
    }
  }
}

output "sql_serverless_connection_info" {
  description = "Connection information for SQL Serverless instances"
  value = {
    for k, v in azurerm_mssql_server.serverless : k => {
      server_name   = v.name
      fqdn          = "${v.name}.database.windows.net"
      admin_login   = v.administrator_login
      database_name = azurerm_mssql_database.serverless[k].name
      port          = "1433"
      connection_strings = {
        aad_integrated = "Server=tcp:${v.name}.database.windows.net,1433;Database=${azurerm_mssql_database.serverless[k].name};Authentication=Active Directory Default;"
        sql_auth       = "Server=tcp:${v.name}.database.windows.net,1433;Database=${azurerm_mssql_database.serverless[k].name};User ID=${v.administrator_login};Password=<your_password>;Encrypt=true;Connection Timeout=30;"
      }
      usage_tips = {
        sqlcmd = "sqlcmd -S ${v.name}.database.windows.net -d ${azurerm_mssql_database.serverless[k].name} -U ${v.administrator_login} -P <your_password>"
        azcli  = "az sql db show -g ${v.resource_group_name} -s ${v.name} -n ${azurerm_mssql_database.serverless[k].name}"
      }
    }
  }
  sensitive = true
}

# =========================================
# Azure SQL Elastic Pool Outputs
# =========================================

output "sql_elastic_summary" {
  description = "Summary of SQL Elastic Pool deployment"
  value = var.enable_sql_elastic_pool ? {
    total_instances = length(var.sql_elastic_instances)
    instances = {
      for k, v in var.sql_elastic_instances : k => {
        server_name          = v.server_name
        elastic_pool_name    = v.elastic_pool_name
        pool_size            = "${v.elastic_pool_max_size_gb} GB"
        pool_sku             = v.elastic_pool_sku
        database_count       = length(v.databases)
        total_databases_size = sum([for db in v.databases : db.max_size_gb])
      }
    }
  } : null
}

output "sql_elastic_servers" {
  description = "Map of SQL Elastic Pool servers with their details"
  value = {
    for k, v in azurerm_mssql_server.elastic : k => {
      name           = v.name
      id             = v.id
      fqdn           = "${v.name}.database.windows.net"
      admin_login    = v.administrator_login
      version        = v.version
      location       = v.location
      identity       = try(v.identity[0].type, null)
      public_access  = v.public_network_access_enabled
      minimum_tls    = v.minimum_tls_version
      aad_admin      = try(v.azuread_administrator[0].login_username, null)
      resource_group = v.resource_group_name
    }
  }
  sensitive = true
}

output "sql_elastic_pools" {
  description = "Map of SQL Elastic Pools with their details"
  value = {
    for k, v in azurerm_mssql_elasticpool.pool : k => {
      name           = v.name
      id             = v.id
      server_name    = v.server_name
      max_size_gb    = v.max_size_gb
      zone_redundant = try(v.zone_redundant, false)
      location       = v.location
      license_type   = try(v.license_type, "LicenseIncluded")
      sku = {
        name     = v.sku[0].name
        tier     = v.sku[0].tier
        family   = v.sku[0].family
        capacity = v.sku[0].capacity
      }
      per_database_settings = {
        min_capacity = v.per_database_settings[0].min_capacity
        max_capacity = v.per_database_settings[0].max_capacity
      }
      tags = v.tags
    }
  }
}

output "sql_elastic_databases" {
  description = "Map of SQL Elastic Pool databases with their details"
  value = {
    for k, v in azurerm_mssql_database.elastic : k => {
      name               = v.name
      id                 = v.id
      elastic_pool_id    = v.elastic_pool_id
      elastic_pool_name  = split("/", v.elastic_pool_id)[10]
      server_name        = split("/", v.server_id)[8]
      max_size_gb        = v.max_size_gb
      zone_redundant     = v.zone_redundant
      collation          = v.collation
      license_type       = v.license_type
      read_scale         = try(v.read_scale, false)
      geo_backup_enabled = try(v.geo_backup_enabled, true)
      tags               = v.tags
    }
  }
}

output "sql_elastic_private_endpoints" {
  description = "Map of SQL Elastic Pool private endpoints"
  value = {
    for k, v in azurerm_private_endpoint.sql_elastic : k => {
      name = v.name
      id   = v.id
      private_service_connection = {
        name      = v.private_service_connection[0].name
        status    = v.private_service_connection[0].private_connection_resource_id
        is_manual = v.private_service_connection[0].is_manual_connection
      }
      subnet_id = v.subnet_id
      location  = v.location
      dns_zones = try(v.private_dns_zone_group[0].private_dns_zone_ids, [])
      tags      = v.tags
    }
  }
}

output "sql_elastic_connection_info" {
  description = "Connection information for SQL Elastic Pool instances"
  value = {
    for k, v in azurerm_mssql_server.elastic : k => {
      server_name  = v.name
      fqdn         = "${v.name}.database.windows.net"
      admin_login  = v.administrator_login
      elastic_pool = azurerm_mssql_elasticpool.pool[k].name
      port         = "1433"
      databases = {
        for db_key, db in azurerm_mssql_database.elastic : db_key => {
          name        = db.name
          max_size_gb = db.max_size_gb
          connection_strings = {
            aad_integrated = "Server=tcp:${v.name}.database.windows.net,1433;Database=${db.name};Authentication=Active Directory Default;"
            sql_auth       = "Server=tcp:${v.name}.database.windows.net,1433;Database=${db.name};User ID=${v.administrator_login};Password=<your_password>;Encrypt=true;Connection Timeout=30;"
          }
        }
        if split("/", db.elastic_pool_id)[8] == v.name
      }
      usage_tips = {
        sqlcmd     = "sqlcmd -S ${v.name}.database.windows.net -U ${v.administrator_login} -P <your_password> -d <database_name>"
        azcli_pool = "az sql elastic-pool show -g ${v.resource_group_name} -s ${v.name} -n ${azurerm_mssql_elasticpool.pool[k].name}"
      }
    }
  }
  sensitive = true
}

# =========================================
# Azure Storage Account Outputs
# =========================================

output "storage_account_summary" {
  description = "Summary of Storage Account deployment"
  value = var.enable_storage_account ? {
    total_accounts = length(var.storage_accounts)
    accounts = {
      for k, v in var.storage_accounts : k => {
        name              = v.storage_account_name
        tier              = v.account_tier
        replication       = v.replication_type
        data_lake_gen2    = v.enable_data_lake_gen2
        file_shares_count = length(v.file_shares)
      }
    }
  } : null
}

output "storage_accounts" {
  description = "Map of Storage Accounts with their details"
  value = {
    for k, v in azurerm_storage_account.shared : k => {
      name                     = v.name
      id                       = v.id
      primary_location         = v.primary_location
      secondary_location       = v.secondary_location
      account_tier             = v.account_tier
      account_replication_type = v.account_replication_type
      account_kind             = v.account_kind
      primary_blob_endpoint    = v.primary_blob_endpoint
      primary_file_endpoint    = v.primary_file_endpoint
      primary_queue_endpoint   = v.primary_queue_endpoint
      primary_table_endpoint   = v.primary_table_endpoint
      primary_dfs_endpoint     = v.primary_dfs_endpoint
      is_hns_enabled           = v.is_hns_enabled
      identity = {
        type         = v.identity[0].type
        principal_id = v.identity[0].principal_id
        tenant_id    = v.identity[0].tenant_id
      }
    }
  }
}

output "storage_file_shares" {
  description = "Map of Storage File Shares with their details"
  value = {
    for k, v in azurerm_storage_share.shares : k => {
      name                 = v.name
      id                   = v.id
      storage_account_name = v.storage_account_name
      quota                = v.quota
      url                  = v.url
      resource_manager_id  = v.resource_manager_id
    }
  }
}

output "storage_private_endpoints" {
  description = "Map of Storage Private Endpoints with their details"
  value = merge(
    {
      for k, v in azurerm_private_endpoint.storage_blob : "blob-${k}" => {
        name         = v.name
        id           = v.id
        subnet_id    = v.subnet_id
        subresource  = "blob"
        storage_name = split("/", v.private_service_connection[0].private_connection_resource_id)[8]
      }
    },
    {
      for k, v in azurerm_private_endpoint.storage_file : "file-${k}" => {
        name         = v.name
        id           = v.id
        subnet_id    = v.subnet_id
        subresource  = "file"
        storage_name = split("/", v.private_service_connection[0].private_connection_resource_id)[8]
      }
    }
  )
}

output "storage_rbac_assignments" {
  description = "Summary of Storage RBAC role assignments"
  value = var.enable_storage_account ? {
    blob_readers = {
      for k, v in azurerm_role_assignment.storage_blob_reader : k => {
        role         = "Storage Blob Data Reader"
        principal_id = v.principal_id
        scope_name   = split("/", v.scope)[8]
      }
    }
    blob_contributors = {
      for k, v in azurerm_role_assignment.storage_blob_contributor : k => {
        role         = "Storage Blob Data Contributor"
        principal_id = v.principal_id
        scope_name   = split("/", v.scope)[8]
      }
    }
    file_readers = {
      for k, v in azurerm_role_assignment.storage_file_reader : k => {
        role         = "Storage File Data SMB Share Reader"
        principal_id = v.principal_id
        scope_name   = split("/", v.scope)[8]
      }
    }
    file_contributors = {
      for k, v in azurerm_role_assignment.storage_file_contributor : k => {
        role         = "Storage File Data SMB Share Contributor"
        principal_id = v.principal_id
        scope_name   = split("/", v.scope)[8]
      }
    }
  } : null
}

output "storage_connection_info" {
  description = "Connection information for Storage Accounts"
  value = {
    for k, v in azurerm_storage_account.shared : k => {
      name = v.name
      endpoints = {
        blob  = v.primary_blob_endpoint
        file  = v.primary_file_endpoint
        queue = v.primary_queue_endpoint
        table = v.primary_table_endpoint
        dfs   = v.is_hns_enabled ? v.primary_dfs_endpoint : null
      }
      access_methods = {
        managed_identity = "Use Azure AD authentication with Managed Identity (recommended)"
        sas_token        = "Generate SAS token via Azure Portal or CLI"
        private_endpoint = v.public_network_access_enabled ? "Available via VNet (Private Endpoint configured)" : "Private Endpoint only"
      }
      usage_examples = {
        azcli_blob_upload = "az storage blob upload --account-name ${v.name} --container-name <container> --file <local-file> --name <blob-name> --auth-mode login"
        azcli_file_upload = "az storage file upload --account-name ${v.name} --share-name <share> --source <local-file> --auth-mode login"
        powershell        = "$ctx = New-AzStorageContext -StorageAccountName '${v.name}' -UseConnectedAccount; Get-AzStorageBlob -Container '<container>' -Context $ctx"
      }
      security_features = {
        versioning_enabled    = var.storage_accounts[k].enable_versioning
        soft_delete_days      = var.storage_accounts[k].soft_delete_days
        public_access_blocked = !v.public_network_access_enabled
        key_access_disabled   = !var.storage_accounts[k].shared_access_key_enabled
      }
    }
  }
  sensitive = true
}
