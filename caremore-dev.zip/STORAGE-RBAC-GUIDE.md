# Azure Storage Account - RBAC Access Management Guide

This guide explains how to configure and manage Azure Storage Account access using Role-Based Access Control (RBAC) in the infrastructure code.

## Overview

The storage account configuration (`8-azure-storage-account.tf`) provides:
- **Secure by default**: Private endpoints, no public access, key access disabled
- **RBAC-based access**: Managed Identity and Azure AD authentication
- **Multiple service types**: Blob, File, Queue support
- **Data Lake Gen2**: Optional hierarchical namespace
- **Enterprise features**: Versioning, soft delete, resource locks

## Configuration Structure

### Storage Account Configuration

```hcl
storage_accounts = {
  platform01 = {
    # Basic settings
    storage_account_name = "stplatformcaremoredev"
    account_tier        = "Standard"
    replication_type    = "ZRS"
    account_kind        = "StorageV2"
    
    # Security
    public_network_access_enabled = false
    allow_blob_public_access     = false
    shared_access_key_enabled    = false
    
    # Data protection
    enable_versioning = true
    soft_delete_days  = 7
    
    # Data Lake Gen2
    enable_data_lake_gen2 = true
    
    # Network
    network_default_action = "Deny"
    allowed_subnet_ids    = ["<subnet-id>"]
    network_bypass        = ["AzureServices"]
    
    # Private endpoints
    private_endpoint_enabled = true
    pe_enable_blob          = true
    pe_enable_file          = true
    pe_enable_queue         = true
    
    # Containers, shares, queues
    containers  = { ... }
    file_shares = { ... }
    queues      = { ... }
    
    # RBAC access control
    rbac_blob_readers      = { ... }
    rbac_blob_contributors = { ... }
    rbac_file_readers      = { ... }
    rbac_file_contributors = { ... }
    
    # Protection
    enable_resource_lock = true
  }
}
```

## RBAC Access Management

### Step 1: Get Principal IDs

You need the **Object ID (Principal ID)** of users, groups, service principals, or managed identities to grant access.

#### Get User Principal ID
```bash
az ad user show --id user@domain.com --query id -o tsv
```

#### Get Group Principal ID
```bash
az ad group show --group "Team-Platform-Dev" --query id -o tsv
```

#### Get Managed Identity Principal ID
```bash
# System-assigned MI (from VM, App Service, etc.)
az vm show -g <rg> -n <vm-name> --query identity.principalId -o tsv

# User-assigned MI
az identity show -g <rg> -n <identity-name> --query principalId -o tsv
```

#### Get Service Principal Principal ID
```bash
az ad sp show --id <app-id> --query id -o tsv
```

### Step 2: Configure RBAC in tfvars

Add the principal IDs to the appropriate RBAC map in `caremore-dev.tfvars`:

```hcl
storage_accounts = {
  platform01 = {
    # ... other config ...
    
    # Read-only access to blobs
    rbac_blob_readers = {
      "analytics-team"    = "12345678-1234-1234-1234-123456789012"
      "reporting-user"    = "87654321-4321-4321-4321-210987654321"
      "vm-managed-id"     = "abcdef12-3456-7890-abcd-ef1234567890"
    }
    
    # Read/write access to blobs
    rbac_blob_contributors = {
      "data-pipeline-mi"  = "fedcba98-7654-3210-fedc-ba9876543210"
      "platform-admins"   = "11111111-2222-3333-4444-555555555555"
    }
    
    # Read-only access to file shares
    rbac_file_readers = {
      "app-service-mi"    = "22222222-3333-4444-5555-666666666666"
    }
    
    # Read/write access to file shares
    rbac_file_contributors = {
      "integration-team"  = "33333333-4444-5555-6666-777777777777"
    }
  }
}
```

### Step 3: Apply Configuration

```bash
cd terraform-Infrastructure-code
terraform plan -var-file="caremore-dev.tfvars"
terraform apply -var-file="caremore-dev.tfvars"
```

## RBAC Role Definitions

| Role | Permissions | Use Case |
|------|-------------|----------|
| **Storage Blob Data Reader** | Read blobs and list containers | Analytics, reporting, read-only access |
| **Storage Blob Data Contributor** | Read, write, delete blobs | Data pipelines, ETL jobs, backup services |
| **Storage File Data SMB Share Reader** | Read files via SMB | Application config access, shared docs |
| **Storage File Data SMB Share Contributor** | Read/write files via SMB | File integration, shared workspaces |

## Access Patterns

### Pattern 1: Managed Identity Access (Recommended)

**Scenario**: Azure VM needs to read/write blobs

1. Enable system-assigned managed identity on VM
2. Get the principal ID:
   ```bash
   az vm show -g RG-Platform-caremore-dev -n win-sql-ssrs-01 --query identity.principalId -o tsv
   ```
3. Add to `rbac_blob_contributors` in tfvars
4. Apply Terraform
5. From the VM, use Azure CLI with managed identity:
   ```bash
   az storage blob upload \
     --account-name stplatformcaremoredev \
     --container-name data \
     --file local-file.csv \
     --name remote-file.csv \
     --auth-mode login
   ```

### Pattern 2: Azure AD Group Access

**Scenario**: Give an entire team read access to logs

1. Create or identify the Azure AD group:
   ```bash
   az ad group create --display-name "Team-Platform-Logs-Readers" --mail-nickname team-platform-logs
   ```
2. Get the group principal ID:
   ```bash
   az ad group show --group "Team-Platform-Logs-Readers" --query id -o tsv
   ```
3. Add to `rbac_blob_readers` in tfvars:
   ```hcl
   rbac_blob_readers = {
     "platform-logs-team" = "group-principal-id-here"
   }
   ```
4. Apply Terraform
5. Team members can access using their own Azure AD credentials:
   ```bash
   az login
   az storage blob list --account-name stplatformcaremoredev --container-name logs --auth-mode login
   ```

### Pattern 3: Service Principal Access

**Scenario**: External application needs to upload backups

1. Create service principal:
   ```bash
   az ad sp create-for-rbac --name "backup-service-principal" --skip-assignment
   ```
2. Get the principal ID (not app ID):
   ```bash
   az ad sp show --id <app-id-from-step-1> --query id -o tsv
   ```
3. Add to `rbac_blob_contributors` in tfvars
4. Apply Terraform
5. Use service principal credentials in application

### Pattern 4: User-Assigned Managed Identity

**Scenario**: Multiple resources share the same identity

1. Create user-assigned managed identity:
   ```bash
   az identity create -g RG-Platform-caremore-dev -n mi-storage-access
   ```
2. Get principal ID:
   ```bash
   az identity show -g RG-Platform-caremore-dev -n mi-storage-access --query principalId -o tsv
   ```
3. Add to RBAC map in tfvars
4. Apply Terraform
5. Assign identity to resources (VMs, App Services, etc.)

## Container-Level vs Account-Level Access

Currently, RBAC is assigned at the **storage account level**. To grant access to specific containers only:

**Option 1**: Use separate storage accounts for different data domains

**Option 2**: Apply RBAC at container scope manually:
```bash
az role assignment create \
  --role "Storage Blob Data Reader" \
  --assignee <principal-id> \
  --scope "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage>/blobServices/default/containers/<container>"
```

**Option 3**: Use Data Lake Gen2 ACLs (when `enable_data_lake_gen2 = true`):
```bash
az storage fs access set \
  --acl "user:<principal-id>:rwx" \
  --path /data/restricted \
  -f <container> \
  --account-name stplatformcaremoredev \
  --auth-mode login
```

## Security Best Practices

✅ **DO**:
- Use Managed Identities whenever possible
- Disable shared access key authentication (`shared_access_key_enabled = false`)
- Use private endpoints (`private_endpoint_enabled = true`)
- Enable versioning and soft delete for data protection
- Apply resource locks to prevent accidental deletion
- Use ZRS or GZRS for high availability
- Monitor access with Storage Analytics logs

❌ **DON'T**:
- Share storage account keys in code or environment variables
- Enable public blob access (`allow_blob_public_access = false`)
- Allow public network access unless required
- Grant overly broad permissions (use least privilege)
- Use SAS tokens for long-term access

## Troubleshooting RBAC Access

### "Authorization failed" when accessing storage

**Check 1**: Verify role assignment exists
```bash
az role assignment list \
  --assignee <principal-id> \
  --scope /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage>
```

**Check 2**: Wait for RBAC propagation (can take 5-10 minutes)

**Check 3**: Ensure using `--auth-mode login` (not access keys)

**Check 4**: Verify network access (private endpoint, firewall rules)

### How to remove access

1. Remove the principal ID from the RBAC map in tfvars
2. Run `terraform apply`
3. Terraform will destroy the role assignment

Alternatively, remove manually:
```bash
az role assignment delete \
  --assignee <principal-id> \
  --role "Storage Blob Data Reader" \
  --scope <storage-account-id>
```

## Common Use Cases

### Use Case 1: Terraform Remote State

```hcl
containers = {
  tfstate = {
    name                  = "tfstate"
    container_access_type = "private"
  }
}

rbac_blob_contributors = {
  "terraform-pipeline-sp" = "sp-principal-id"
}
```

### Use Case 2: Shared Logs Repository

```hcl
containers = {
  logs = {
    name                  = "logs"
    container_access_type = "private"
  }
}

rbac_blob_contributors = {
  "diagnostic-settings" = "system-managed-identity"
}

rbac_blob_readers = {
  "security-team"   = "group-principal-id"
  "platform-admins" = "group-principal-id"
}
```

### Use Case 3: Data Lake for Analytics

```hcl
enable_data_lake_gen2 = true

containers = {
  raw = { name = "raw", container_access_type = "private" }
  processed = { name = "processed", container_access_type = "private" }
}

rbac_blob_contributors = {
  "databricks-mi" = "databricks-principal-id"
  "synapse-mi"    = "synapse-principal-id"
}

rbac_blob_readers = {
  "data-analysts" = "group-principal-id"
}
```

## Monitoring and Auditing

Enable diagnostic settings to track storage access:

```bash
az monitor diagnostic-settings create \
  --resource <storage-account-id> \
  --name storage-diagnostics \
  --workspace <log-analytics-workspace-id> \
  --logs '[{"category":"StorageRead","enabled":true},{"category":"StorageWrite","enabled":true}]' \
  --metrics '[{"category":"Transaction","enabled":true}]'
```

Query access logs in Log Analytics:
```kusto
StorageBlobLogs
| where TimeGenerated > ago(24h)
| where AuthenticationType == "OAuth"
| project TimeGenerated, CallerIpAddress, ObjectKey, OperationName, StatusText
| order by TimeGenerated desc
```

## Additional Resources

- [Azure Storage RBAC Documentation](https://docs.microsoft.com/en-us/azure/storage/common/storage-auth-aad-rbac-portal)
- [Managed Identity Overview](https://docs.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview)
- [Data Lake Gen2 ACLs](https://docs.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-access-control)
- [Private Endpoints](https://docs.microsoft.com/en-us/azure/private-link/private-endpoint-overview)

---

**Support**: For issues or questions, contact TG-Mosaic-Cloud Infrastructure
