# Azure SQL Server with Elastic Pool Configuration
locals {
  sql_elastic_instances_with_pe = {
    for k, v in var.sql_elastic_instances : k => v
    if var.enable_sql_elastic_pool && v.private_endpoint_enabled
  }
}

# Azure SQL Server
resource "azurerm_mssql_server" "elastic" {
  for_each                     = var.enable_sql_elastic_pool ? var.sql_elastic_instances : {}
  name                         = each.value.server_name
  resource_group_name          = local.resource_group_name
  location                     = local.resource_group_location
  version                      = each.value.server_version
  administrator_login          = each.value.sql_admin_username
  administrator_login_password = each.value.sql_admin_password
  minimum_tls_version          = "1.2"

  # Azure AD Authentication (optional)
  dynamic "azuread_administrator" {
    for_each = each.value.aad_admin_login != null ? [1] : []
    content {
      login_username = each.value.aad_admin_login
      object_id      = each.value.aad_admin_object_id
      tenant_id      = each.value.aad_admin_tenant_id
    }
  }

  public_network_access_enabled = each.value.public_network_access_enabled

  identity {
    type = "SystemAssigned"
  }

  tags = var.tags
}

# Elastic Pool
resource "azurerm_mssql_elasticpool" "pool" {
  for_each            = var.enable_sql_elastic_pool ? var.sql_elastic_instances : {}
  name                = each.value.elastic_pool_name
  resource_group_name = local.resource_group_name
  location            = local.resource_group_location
  server_name         = azurerm_mssql_server.elastic[each.key].name
  max_size_gb         = each.value.elastic_pool_max_size_gb

  sku {
    name     = each.value.elastic_pool_sku.name
    tier     = each.value.elastic_pool_sku.tier
    capacity = each.value.elastic_pool_sku.capacity
  }

  per_database_settings {
    min_capacity = 0
    max_capacity = 100
  }

  zone_redundant = each.value.zone_redundant

  tags = var.tags
}

# Azure SQL Databases
resource "azurerm_mssql_database" "elastic" {
  for_each = {
    for pair in flatten([
      for server_key, server in var.sql_elastic_instances : [
        for db_key, db in server.databases : {
          server_key = server_key
          db_key     = db_key
          db_value   = db
        }
      ]
      ]) : "${pair.server_key}-${pair.db_key}" => {
      server_key = pair.server_key
      db         = pair.db_value
    }
    if var.enable_sql_elastic_pool
  }

  name               = each.value.db.name
  server_id          = azurerm_mssql_server.elastic[each.value.server_key].id
  elastic_pool_id    = azurerm_mssql_elasticpool.pool[each.value.server_key].id
  collation          = each.value.db.collation
  max_size_gb        = each.value.db.max_size_gb
  zone_redundant     = each.value.db.zone_redundant
  geo_backup_enabled = var.sql_elastic_geo_backup_enabled
  license_type       = "LicenseIncluded"

  tags = var.tags
}

# Firewall Rules for SQL Server
resource "azurerm_mssql_firewall_rule" "elastic" {
  for_each = {
    for pair in flatten([
      for server_key, server in var.sql_elastic_instances : [
        for rule_key, rule in server.firewall_rules : {
          server_key = server_key
          rule_key   = rule_key
          rule_value = rule
        }
      ]
      ]) : "${pair.server_key}-${pair.rule_key}" => {
      server_key = pair.server_key
      rule       = pair.rule_value
    }
    if var.enable_sql_elastic_pool
  }

  name             = split("-", each.key)[1]
  server_id        = azurerm_mssql_server.elastic[each.value.server_key].id
  start_ip_address = each.value.rule.start_ip
  end_ip_address   = each.value.rule.end_ip
}

# Private Endpoint for SQL Server
resource "azurerm_private_endpoint" "sql_elastic" {
  for_each            = local.sql_elastic_instances_with_pe
  name                = "${each.value.server_name}-pe"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id

  private_service_connection {
    name                           = "${each.value.server_name}-psc"
    private_connection_resource_id = azurerm_mssql_server.elastic[each.key].id
    is_manual_connection           = false
    subresource_names              = ["sqlServer"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.sql_elastic[0].id]
  }

  tags = var.tags
}

# Private DNS Zone for SQL Server
resource "azurerm_private_dns_zone" "sql_elastic" {
  count               = length(local.sql_elastic_instances_with_pe) > 0 ? 1 : 0
  name                = "privatelink.database.windows.net"
  resource_group_name = local.resource_group_name
}

# VNet Links for SQL Server DNS zone
resource "azurerm_private_dns_zone_virtual_network_link" "sql_elastic" {
  count                 = length(local.sql_elastic_instances_with_pe) > 0 ? 1 : 0
  name                  = "${var.environment}-sql-elastic-dnslink"
  resource_group_name   = local.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.sql_elastic[0].name
  virtual_network_id    = local.vnet_id
  registration_enabled  = false
}

# Diagnostic settings for SQL Server
resource "azurerm_monitor_diagnostic_setting" "sql_elastic_server" {
  for_each                   = var.enable_sql_elastic_pool && var.enable_diagnostics && var.log_analytics_workspace_id != null ? var.sql_elastic_instances : {}
  name                       = "${each.value.server_name}-diag"
  target_resource_id         = azurerm_mssql_server.elastic[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "SQLSecurityAuditEvents"
  }

  enabled_log {
    category = "SQLInsights"
  }

  enabled_log {
    category = "AutomaticTuning"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# Diagnostic settings for Elastic Pool
resource "azurerm_monitor_diagnostic_setting" "sql_elastic_pool" {
  for_each                   = var.enable_sql_elastic_pool && var.enable_diagnostics && var.log_analytics_workspace_id != null ? var.sql_elastic_instances : {}
  name                       = "${each.value.elastic_pool_name}-diag"
  target_resource_id         = azurerm_mssql_elasticpool.pool[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "ResourceUsageStats"
  }

  enabled_log {
    category = "ErrorLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# Diagnostic settings for SQL Databases
resource "azurerm_monitor_diagnostic_setting" "sql_elastic_database" {
  for_each = {
    for pair in flatten([
      for server_key, server in var.sql_elastic_instances : [
        for db_key, db in server.databases : {
          server_key = server_key
          db_key     = db_key
          db_name    = db.name
        }
      ]
      ]) : "${pair.server_key}-${pair.db_key}" => {
      server_key = pair.server_key
      db_name    = pair.db_name
    }
    if var.enable_sql_elastic_pool && var.enable_diagnostics && var.log_analytics_workspace_id != null
  }

  name                       = "${each.value.db_name}-diag"
  target_resource_id         = azurerm_mssql_database.elastic[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "SQLInsights"
  }

  enabled_log {
    category = "AutomaticTuning"
  }

  enabled_log {
    category = "QueryStoreRuntimeStatistics"
  }

  enabled_log {
    category = "QueryStoreWaitStatistics"
  }

  enabled_log {
    category = "Errors"
  }

  enabled_log {
    category = "DatabaseWaitStatistics"
  }

  enabled_log {
    category = "Timeouts"
  }

  enabled_log {
    category = "Blocks"
  }

  enabled_log {
    category = "Deadlocks"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}