# Azure SQL Serverless Configuration
locals {
  sql_serverless_instances_with_pe = {
    for k, v in var.sql_serverless_instances : k => v
    if var.enable_sql_serverless && v.private_endpoint_enabled
  }
}

# Azure SQL Server
resource "azurerm_mssql_server" "serverless" {
  for_each                     = var.enable_sql_serverless ? var.sql_serverless_instances : {}
  name                         = each.value.server_name
  resource_group_name          = local.resource_group_name
  location                     = local.resource_group_location
  version                      = each.value.server_version
  administrator_login          = each.value.sql_admin_username
  administrator_login_password = each.value.sql_admin_password
  minimum_tls_version          = "1.2"

  # Azure AD Authentication (optional)
  dynamic "azuread_administrator" {
    for_each = each.value.aad_admin_login != null ? [1] : []
    content {
      login_username = each.value.aad_admin_login
      object_id      = each.value.aad_admin_object_id
      tenant_id      = each.value.aad_admin_tenant_id
    }
  }

  identity {
    type = "SystemAssigned"
  }

  tags = var.tags
}

# Azure SQL Database (Serverless)
resource "azurerm_mssql_database" "serverless" {
  for_each     = var.enable_sql_serverless ? var.sql_serverless_instances : {}
  name         = each.value.database_name
  server_id    = azurerm_mssql_server.serverless[each.key].id
  collation    = "SQL_Latin1_General_CP1_CI_AS"
  license_type = "LicenseIncluded"
  max_size_gb  = each.value.max_size_bytes / (1024 * 1024 * 1024) # Convert bytes to GB

  sku_name = "GP_S_Gen5_1" # Serverless tier with 1 vCore base

  auto_pause_delay_in_minutes = each.value.auto_pause_delay_minutes
  min_capacity                = each.value.minimum_capacity

  tags = var.tags
}

# Firewall Rules for SQL Server
resource "azurerm_mssql_firewall_rule" "serverless" {
  for_each = {
    for pair in flatten([
      for server_key, server in var.sql_serverless_instances : [
        for rule_key, rule in server.firewall_rules : {
          server_key = server_key
          rule_key   = rule_key
          rule_value = rule
        }
      ]
      ]) : "${pair.server_key}-${pair.rule_key}" => {
      server_key = pair.server_key
      rule       = pair.rule_value
    }
    if var.enable_sql_serverless
  }

  name             = split("-", each.key)[1]
  server_id        = azurerm_mssql_server.serverless[each.value.server_key].id
  start_ip_address = each.value.rule.start_ip
  end_ip_address   = each.value.rule.end_ip
}

# Private Endpoint for SQL Server
resource "azurerm_private_endpoint" "sql_serverless" {
  for_each            = local.sql_serverless_instances_with_pe
  name                = "${each.value.server_name}-pe"
  location            = local.resource_group_location
  resource_group_name = local.resource_group_name
  subnet_id           = each.value.private_endpoint_subnet_id

  private_service_connection {
    name                           = "${each.value.server_name}-psc"
    private_connection_resource_id = azurerm_mssql_server.serverless[each.key].id
    is_manual_connection           = false
    subresource_names              = ["sqlServer"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.sql_serverless[0].id]
  }

  tags = var.tags
}

# Private DNS Zone for SQL Server
resource "azurerm_private_dns_zone" "sql_serverless" {
  count               = length(local.sql_serverless_instances_with_pe) > 0 ? 1 : 0
  name                = "privatelink.database.windows.net"
  resource_group_name = local.resource_group_name
}

# VNet Links for SQL Server DNS zone
resource "azurerm_private_dns_zone_virtual_network_link" "sql_serverless" {
  count                 = length(local.sql_serverless_instances_with_pe) > 0 ? 1 : 0
  name                  = "${var.environment}-sql-serverless-dnslink"
  resource_group_name   = local.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.sql_serverless[0].name
  virtual_network_id    = local.vnet_id
  registration_enabled  = false
}

# Diagnostic settings for SQL Server
resource "azurerm_monitor_diagnostic_setting" "sql_serverless_server" {
  for_each                   = var.enable_sql_serverless && var.enable_diagnostics && var.log_analytics_workspace_id != null ? var.sql_serverless_instances : {}
  name                       = "${each.value.server_name}-diag"
  target_resource_id         = azurerm_mssql_server.serverless[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "SQLSecurityAuditEvents"
  }

  enabled_log {
    category = "SQLInsights"
  }

  enabled_log {
    category = "AutomaticTuning"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# Diagnostic settings for SQL Database
resource "azurerm_monitor_diagnostic_setting" "sql_serverless_database" {
  for_each                   = var.enable_sql_serverless && var.enable_diagnostics && var.log_analytics_workspace_id != null ? var.sql_serverless_instances : {}
  name                       = "${each.value.database_name}-diag"
  target_resource_id         = azurerm_mssql_database.serverless[each.key].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "SQLInsights"
  }

  enabled_log {
    category = "AutomaticTuning"
  }

  enabled_log {
    category = "QueryStoreRuntimeStatistics"
  }

  enabled_log {
    category = "QueryStoreWaitStatistics"
  }

  enabled_log {
    category = "Errors"
  }

  enabled_log {
    category = "DatabaseWaitStatistics"
  }

  enabled_log {
    category = "Timeouts"
  }

  enabled_log {
    category = "Blocks"
  }

  enabled_log {
    category = "Deadlocks"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}